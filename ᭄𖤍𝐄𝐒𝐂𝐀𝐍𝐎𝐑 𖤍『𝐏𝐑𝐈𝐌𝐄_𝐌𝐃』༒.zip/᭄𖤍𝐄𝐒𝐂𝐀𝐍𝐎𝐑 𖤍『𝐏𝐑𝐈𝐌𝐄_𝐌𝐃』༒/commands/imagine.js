const axios = require('axios');
const { fetchBuffer } = require('../lib/myfunc');

async function imagineCommand(sock, chatId, message) {
    try {
        const prompt = message.message?.conversation?.trim() || 
                      message.message?.extendedTextMessage?.text?.trim() || '';
        
        const imagePrompt = prompt.slice(8).trim();
        
        if (!imagePrompt) {
            await sock.sendMessage(chatId, {
                text: '☀️ *DONNE-MOI UN PROMPT, MORTEL.* ☀️\nExemple: .imagine un magnifique coucher de soleil'
            }, {
                quoted: message
            });
            return;
        }

        await sock.sendMessage(chatId, {
            text: '☀️ *LE LION GÉNÈRE TON IMAGE...* ☀️\nPatience, mortel.'
        }, {
            quoted: message
        });

        const enhancedPrompt = enhancePrompt(imagePrompt);

        const response = await axios.get(`https://shizoapi.onrender.com/api/ai/imagine?apikey=shizo&query=${encodeURIComponent(enhancedPrompt)}`, {
            responseType: 'arraybuffer'
        });

        const imageBuffer = Buffer.from(response.data);

        await sock.sendMessage(chatId, {
            image: imageBuffer,
            caption: `☀️ *IMAGE GÉNÉRÉE PAR LE LION* ☀️\n\nPrompt: "${imagePrompt}"`
        }, {
            quoted: message
        });

    } catch (error) {
        console.error('☀️ Erreur dans la commande imagine:', error);
        await sock.sendMessage(chatId, {
            text: '☀️ *ÉCHEC DE LA GÉNÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.'
        }, {
            quoted: message
        });
    }
}

function enhancePrompt(prompt) {
    const qualityEnhancers = [
        'haute qualité',
        'détaillé',
        'chef-d\'œuvre',
        'meilleure qualité',
        'ultra réaliste',
        '4k',
        'extrêmement détaillé',
        'éclairage cinématographique',
        'focalisation nette'
    ];

    const numEnhancers = Math.floor(Math.random() * 2) + 3;
    const selectedEnhancers = qualityEnhancers
        .sort(() => Math.random() - 0.5)
        .slice(0, numEnhancers);

    return `${prompt}, ${selectedEnhancers.join(', ')}`;
}

module.exports = imagineCommand;