const fs = require('fs');
const path = require('path');
const { channelInfo } = require('../lib/messageConfig');

const welcomeFile = path.join(__dirname, '../data/globalWelcome.json');
let globalWelcome = false;

const customImages = [
  'https://images.iimg.live/images/wonderful-creation-1886.webp',
  'https://images.iimg.live/images/vibrant-gallery-4281.webp',
  'https://images.iimg.live/images/vibrant-gallery-4281.webp'
];

function loadWelcomeStatus() {
  if (fs.existsSync(welcomeFile)) {
    try {
      const data = JSON.parse(fs.readFileSync(welcomeFile, 'utf8'));
      globalWelcome = !!data.enabled;
    } catch { globalWelcome = false; }
  }
}

function saveWelcomeStatus() {
  fs.writeFileSync(welcomeFile, JSON.stringify({ enabled: globalWelcome }, null, 2));
}

function setWelcome(status) {
  globalWelcome = !!status;
  saveWelcomeStatus();
}

function isWelcomeOn() {
  return globalWelcome;
}

function generateWelcomeMenu(displayName, groupName, groupSize, groupDesc) {
  const now = new Date();
  const dateStr = now.toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });

  return `
☀️ *BIENVENUE DANS L'ANTRE DU LION* ☀️

👤 *Mortel:* @${displayName}
👥 *Groupe:* ${groupName}
📊 *Membres:* ${groupSize}
📝 *Description:* ${groupDesc}

🔥 *Règles du Lion:* 🔥
• Ne défie pas ma fierté
• Respecte les autres mortels
• Aucun lien interdit
• Amuse-toi, mais ne me dérange pas sans raison

☀️ *Que la puissance du soleil t'éclaire, mortel.* ☀️
`;
}

const newsletterContext = (imageUrl) => ({
  forwardingScore: 999,
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363419277738229@newsletter',
    newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
    serverMessageId: Math.floor(Math.random() * 1000)
  },
  externalAdReply: {
    title: "☀️ ESCANOR PRIME ☀️",
    body: "Le Lion t'accueille dans son antre, mortel.",
    thumbnailUrl: imageUrl,
    mediaType: 1,
    renderLargerThumbnail: true,
    sourceUrl: "https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K"
  }
});

async function handleJoinEvent(sock, chatId, participants) {
  if (!isWelcomeOn()) return;

  const groupMetadata = await sock.groupMetadata(chatId);
  const groupName = groupMetadata.subject;
  const groupDesc = groupMetadata.desc || "Aucune description pour ce groupe de mortels.";
  const groupSize = groupMetadata.participants.length;

  for (const participant of participants) {
    try {
      const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
      let displayName = participantString.split('@')[0];

      try {
        const contact = await sock.getBusinessProfile(participantString);
        if (contact?.name) displayName = contact.name;
        else {
          const userParticipant = groupMetadata.participants.find(p => p.id === participantString);
          if (userParticipant?.name) displayName = userParticipant.name;
        }
      } catch {}

      const finalMessage = generateWelcomeMenu(displayName, groupName, groupSize, groupDesc);

      let menuImage = customImages[Math.floor(Math.random() * customImages.length)];

      try {
        const pic = await sock.profilePictureUrl(chatId, 'image');
        if (pic) menuImage = pic;
      } catch {}

      await sock.sendMessage(chatId, {
        image: { url: menuImage },
        caption: finalMessage,
        mentions: [participantString],
        contextInfo: newsletterContext(menuImage),
        ...channelInfo
      });

    } catch (err) {
      console.error('☀️ Erreur envoi welcome:', err);
      const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
      await sock.sendMessage(chatId, { text: `☀️ Bienvenue @${participantString} ! Le Lion te salue. ☀️`, mentions: [participantString], ...channelInfo });
    }
  }
}

async function welcomeCommand(sock, chatId, message) {
  const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
  const args = text.trim().split(' ').slice(1);

  if (args[0]?.toLowerCase() === 'on') {
    setWelcome(true);
    await sock.sendMessage(chatId, { text: '☀️ *ACCUEIL ACTIVÉ* ☀️\nLe Lion accueillera désormais les nouveaux mortels.' });

  } else if (args[0]?.toLowerCase() === 'off') {
    setWelcome(false);
    await sock.sendMessage(chatId, { text: '☀️ *ACCUEIL DÉSACTIVÉ* ☀️\nLe Lion n'accueillera plus les nouveaux mortels.' });

  } else if (args[0]?.toLowerCase() === 'test') {
    await handleJoinEvent(sock, chatId, [message.key?.participant]);

  } else {
    await sock.sendMessage(chatId, {
      text: '☀️ *COMMANDE WELCOME* ☀️\n\n.welcome on - Activer l\'accueil\n.welcome off - Désactiver l\'accueil\n.welcome test - Tester le message'
    });
  }
}

loadWelcomeStatus();

module.exports = { handleJoinEvent, welcomeCommand, setWelcome, isWelcomeOn, customImages };