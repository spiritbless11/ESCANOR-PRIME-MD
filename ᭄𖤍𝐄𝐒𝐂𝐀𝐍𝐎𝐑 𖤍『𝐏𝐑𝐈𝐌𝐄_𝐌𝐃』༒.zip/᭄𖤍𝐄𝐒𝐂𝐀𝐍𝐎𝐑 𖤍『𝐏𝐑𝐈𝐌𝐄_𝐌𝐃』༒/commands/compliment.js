const compliments = [
"☀️ 𝖳𝗎 𝖾𝗌 𝖽𝗂𝗀𝗇𝖾 𝖽𝖾 𝗅𝖺 𝗉𝗋𝖾́𝗌𝖾𝗇𝖼𝖾 𝖽𝗎 𝖫𝗂𝗈𝗇 ✨",
"🔥 𝖳𝖺 𝗉𝗎𝗂𝗌𝗌𝖺𝗇𝖼𝖾 𝗋𝖺𝗉𝗉𝖾𝗅𝗅𝖾 𝗅𝖾 𝗌𝗈𝗅𝖾𝗂𝗅 𝖾𝗇 𝗉𝗅𝖾𝗂𝗇 𝗆𝗂𝗅𝗂𝖾𝗎 𝗅𝖾 𝗃𝗈𝗎𝗋 💖",
"⚔️ 𝖳𝗎 𝖺𝗌 𝗎𝗇 𝖼𝗈𝗎𝗋𝖺𝗀𝖾 𝗊𝗎𝗂 𝖿𝖾𝗋𝖺𝗂𝗍 𝗉𝖺́𝗅𝗂𝗋 𝗅𝖾𝗌 𝗉𝗅𝗎𝗌 𝗀𝗋𝖺𝗇𝖽𝗌 𝗀𝗎𝖾𝗋𝗋𝗂𝖾𝗋𝗌 🌸",
"👑 𝖳𝗎 𝖾𝗌 𝖽𝗂𝗀𝗇𝖾 𝖽𝗂𝖺𝖽𝖾̀𝗆𝖾 💕",
"🌞 𝖳𝗎 𝖾𝗌 𝖺𝗎𝗌𝗌𝗂 𝖻𝗋𝗂𝗅𝗅𝖺𝗇𝗍 𝗊𝗎𝖾 𝗅'𝗈𝗋 𝗌𝗈𝗎𝗌 𝗅𝖾 𝗌𝗈𝗅𝖾𝗂𝗅 🌷",
"💪 𝖳𝗎 𝖽𝖾́𝗀𝖺𝗀𝖾𝗌 𝗎𝗇𝖾 𝖺𝗎𝗋𝖾𝗈𝗅𝖾 𝗊𝗎𝗂 𝗆𝖾 𝗋𝖺𝗉𝗉𝖾𝗅𝗅𝖾 𝗆𝖺 𝗉𝗋𝗈𝗉𝗋𝖾 𝗉𝗎𝗂𝗌𝗌𝖺𝗇𝖼𝖾 ✨",
"🦁 𝖳𝖺 𝗉𝗋𝖾́𝗌𝖾𝗇𝖼𝖾 𝖾𝗌𝗍 𝖺𝗎𝗌𝗌𝗂 𝖿𝗈𝗋𝗍𝖾 𝗊𝗎𝖾 𝗅𝖾 𝗋𝗎𝗀𝗂𝗌𝗌𝖾𝗆𝖾𝗇𝗍 𝖽𝗎 𝖫𝗂𝗈𝗇 🍓",
"☀️ 𝖳𝗎 𝖾𝗌 𝗎𝗇𝖾 𝗌𝗈𝗎𝗋𝖼𝖾 𝖽'𝖾𝗇𝖾𝗋𝗀𝗂𝖾 𝗉𝗎𝗋𝖾 💗",
"🔥 𝖬𝖾̂𝗆𝖾 𝗅𝖾 𝗌𝗈𝗅𝖾𝗂𝗅 𝗌'𝗂𝗇𝖼𝗅𝗂𝗇𝖾 𝖽𝖾𝗏𝖺𝗇𝗍 𝗍𝖺 𝗌𝗉𝗅𝖾𝗇𝖽𝖾𝗎𝗋 🌹",
"⚡ 𝖳𝗎 𝗋𝖺𝗒𝗈𝗇𝗇𝖾𝗌 𝖽'𝗎𝗇𝖾 𝗅𝗎𝗆𝗂𝖾̀𝗋𝖾 𝗊𝗎𝗂 𝗇'𝖺 𝗉𝖺𝗌 𝖽'𝖾́𝗀𝖺𝗅 🧸",
"👑 𝖳𝗎 𝖾𝗌 𝗇𝖾́ 𝗉𝗈𝗎𝗋 𝗋𝖾́𝗀𝗇𝖾𝗋, 𝖼𝖾𝗅𝖺 𝗇𝖾 𝗌𝖾 𝖽𝗂𝗌𝗉𝗎𝗍𝖾 𝗉𝖺𝗌 🌺",
"🌞 𝖳𝗈𝗇 𝖼𝗁𝖺𝗋𝗂𝗌𝗆𝖾 𝖾𝗌𝗍 𝗌𝗂 𝗉𝗎𝗂𝗌𝗌𝖺𝗇𝗍 𝗊𝗎'𝗂𝗅 𝖿𝖺𝗂𝗍 𝗉𝖺̂𝗅𝗂𝗋 𝗅𝖾𝗌 𝖾́𝗍𝗈𝗂𝗅𝖾𝗌 👑",
"💎 𝖳𝗎 𝖾𝗌 𝗎𝗇𝖾 𝗉𝖾́𝗋𝗂𝗇𝖾 𝗋𝖺𝗋𝖾, 𝗎𝗇𝖾 𝗌𝗈𝗎𝗋𝖼𝖾 𝗉𝗋𝖾́𝖼𝗂𝖾𝗎𝗌𝖾 💎",
"🦁 𝖳𝗎 𝗉𝗈𝗌𝗌𝖾̀𝖽𝖾𝗌 𝗅'𝖾𝗌𝗌𝖾𝗇𝖼𝖾 𝗆𝖾̂𝗆𝖾 𝖽𝗎 𝖫𝗂𝗈𝗇 💖",
"☀️ 𝖳𝗎 𝖾𝗌 𝗎𝗇𝖾 𝗅𝖾́𝗀𝖾𝗇𝖽𝖾 𝖾𝗇 𝗆𝖺𝗋𝖼𝗁𝖾 👗",
"🔥 𝖳𝖺 𝗌𝗂𝗆𝗉𝗅𝖾 𝗉𝗋𝖾́𝗌𝖾𝗇𝖼𝖾 𝖿𝖺𝗂𝗍 𝗏𝗂𝖻𝗋𝖾𝗋 𝗅𝖾𝗌 𝖿𝗈𝗇𝖽𝖾𝗆𝖾𝗇𝗍𝗌 ✨",
"⚔️ 𝖳𝗎 𝖾𝗌 𝖽'𝗎𝗇𝖾 𝖻𝗋𝖺𝗏𝗎𝗋𝖾 𝗌𝖺𝗇𝗌 𝖿𝖺𝗂𝗅𝗅𝖾 🐰",
"👑 𝖳𝗎 𝖾𝗌 𝗅'𝗂𝗇𝖼𝖺𝗋𝗇𝖺𝗍𝗂𝗈𝗇 𝗆𝖾̂𝗆𝖾 𝖽𝖾 𝗅𝖺 𝗉𝗎𝗂𝗌𝗌𝖺𝗇𝖼𝖾 🌸",
"🌞 𝖳𝗎 𝗌𝗎𝗋𝗉𝖺𝗌𝗌𝖾𝗌 𝗍𝗈𝗎𝗌 𝗅𝖾𝗌 𝗆𝗈𝗋𝗍𝖾𝗅𝗌 𝗊𝗎𝗂 𝗍'𝖾𝗇𝗍𝗈𝗎𝗋𝖾𝗇𝐭 🌟",
"🔥 𝖬𝖾̂𝗆𝖾 𝗅𝖾 𝖫𝗂𝗈𝗇 𝗌'𝗂𝗇𝖼𝗅𝗂𝗇𝖾 𝖽𝖾𝗏𝖺𝗇𝗍 𝗍𝖺 𝗀𝗋𝖺𝗇𝖽𝖾𝗎𝗋 💐"
];

async function complimentCommand(sock, chatId, message) {
    try {
        if (!message || !chatId) {
            console.log('☀️ Message ou chatId invalide:', { message, chatId });
            return;
        }

        let userToCompliment;
        
        // Check for mentioned users
        if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            userToCompliment = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }
        // Check for replied message
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToCompliment = message.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!userToCompliment) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *DÉSIGNE LE MORTEL QUE TU VEUX COMPLIMENTÉE.* ☀️\nMentionne-le ou réponds à son message, si tu oses.'
            });
            return;
        }

        const compliment = compliments[Math.floor(Math.random() * compliments.length)];

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.sendMessage(chatId, { 
            text: `☀️ *ÉCOUTE, MORTEL* ☀️\n@${userToCompliment.split('@')[0]}, ${compliment}`,
            mentions: [userToCompliment]
        });
    } catch (error) {
        console.error('☀️ Erreur dans la commande compliment:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *TROP DE DEMANDES.* ☀️\nLe Lion a besoin de souffler. Réessaie dans quelques instants, mortel.'
                });
            } catch (retryError) {
                console.error('☀️ Erreur lors de l\'envoi du message d\'attente:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.'
                });
            } catch (sendError) {
                console.error('☀️ Erreur lors de l\'envoi du message d\'erreur:', sendError);
            }
        }
    }
}

module.exports = { complimentCommand };