const { handleAntiBadwordCommand } = require('../lib/antibadword');
const isAdminHelper = require('../lib/isAdmin');

async function antibadwordCommand(sock, chatId, message, senderId, isSenderAdmin) {
    try {
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT UTILISER CETTE COMMANDE.* ☀️\nLe Lion n\'obéit qu\'à ceux qui ont le pouvoir.' }, { quoted: message });
            return;
        }

        // Extract match from message
        const text = message.message?.conversation || 
                    message.message?.extendedTextMessage?.text || '';
        const match = text.split(' ').slice(1).join(' ');

        await handleAntiBadwordCommand(sock, chatId, message, match);
    } catch (error) {
        console.error('☀️ Erreur dans la commande antibadword:', error);
        await sock.sendMessage(chatId, { text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' }, { quoted: message });
    }
}

module.exports = antibadwordCommand;