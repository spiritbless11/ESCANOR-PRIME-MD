const eightBallResponses = [
    "☀️ *OUI, C'EST ABSOLUMENT CERTAIN.* ☀️",
    "🔥 *NON, MORTEL. TU TE TROMPES.* 🔥",
    "☀️ *REPOSE TA QUESTION PLUS TARD.* ☀️",
    "⚔️ *CELA EST ÉVIDENT. OUI.* ⚔️",
    "☀️ *FORT DOUTEUX. PRESQUE IMPOSSIBLE.* ☀️",
    "🔥 *SANS AUCUN DOUTE.* 🔥",
    "☀️ *MA RÉPONSE EST NON. ACCEPTE-LE.* ☀️",
    "⚔️ *LES SIGNES POINTENT VERS OUI.* ⚔️"
];

async function eightBallCommand(sock, chatId, question) {
    if (!question) {
        await sock.sendMessage(chatId, { text: '☀️ *POSE TA QUESTION, MORTEL.* ☀️' });
        return;
    }

    const randomResponse = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];
    await sock.sendMessage(chatId, { text: `☀️ ${randomResponse}` });
}

module.exports = { eightBallCommand };