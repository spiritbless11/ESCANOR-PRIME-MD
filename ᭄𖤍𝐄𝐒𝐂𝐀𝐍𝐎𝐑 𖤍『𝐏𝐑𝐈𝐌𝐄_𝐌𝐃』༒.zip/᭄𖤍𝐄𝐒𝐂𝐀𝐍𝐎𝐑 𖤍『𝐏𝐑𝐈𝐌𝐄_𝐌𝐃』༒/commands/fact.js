const axios = require('axios');

module.exports = async function (sock, chatId, message) {
    try {
        const response = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');
        const fact = response.data.text;
        await sock.sendMessage(chatId, { text: `☀️ *FAIT DU LION* ☀️\n\n${fact}` },{ quoted: message });
    } catch (error) {
        console.error('☀️ Erreur lors de la récupération du fait:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' },{ quoted: message });
    }
};