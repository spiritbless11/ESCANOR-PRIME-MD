const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

async function characterCommand(sock, chatId, message) {
    let userToAnalyze;
    
    // Check for mentioned users
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // Check for replied message
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToAnalyze) {
        await sock.sendMessage(chatId, { 
            text: '☀️ *DÉSIGNE LE MORTEL À ANALYSER.* ☀️\nMentionne-le ou réponds à son message, si tu oses.', 
            ...channelInfo 
        });
        return;
    }

    try {
        // Get user's profile picture
        let profilePic;
        try {
            profilePic = await sock.profilePictureUrl(userToAnalyze, 'image');
        } catch {
            profilePic = 'https://i.imgur.com/2wzGhpF.jpeg'; // Default image if no profile pic
        }

        const traits = [
            "☀️ 𝕱𝖎𝖊𝖗", "🔥 𝕻𝖚𝖎𝖘𝖘𝖆𝖓𝖙", "⚔️ 𝕳𝖔𝖓𝖓𝖊𝖚𝖗𝖆𝖇𝖑𝖊", "👑 𝕯𝖎𝖌𝖓𝖊", "🌞 𝕽𝖆𝖞𝖔𝖓𝖓𝖆𝖓𝖙",
            "🛡️ 𝕻𝖗𝖔𝖙𝖊𝖈𝖙𝖊𝖚𝖗", "💪 𝕴𝖓𝖉𝖔𝖒𝖙𝖆𝖇𝖑𝖊", "✨ 𝕰𝖝𝖈𝖊𝖕𝖙𝖎𝖔𝖓𝖓𝖊𝖑", "🎯 𝕻𝖗é𝖈𝖎𝖘", "🌟 𝕲𝖗𝖆𝖓𝖉",
            "⚡ 𝕰𝖑𝖊𝖈𝖙𝖗𝖎𝖋𝖎𝖆𝖓𝖙", "🏆 𝖁𝖆𝖎𝖓𝖖𝖚𝖊𝖚𝖗", "🔱 𝕴𝖓𝖉𝖔𝖒𝖙𝖆𝖇𝖑𝖊", "🌅 𝕸𝖆𝖏𝖊𝖘𝖙𝖚𝖊𝖚𝖝", "💥 𝕰𝖝𝖕𝖑𝖔𝖘𝖎𝖋",
            "🎖️ 𝕳𝖊́𝖗𝖔𝖎̈𝖖𝖚𝖊", "🔥 𝕬𝖗𝖉𝖊𝖓𝖙", "☀️ 𝕽𝖆𝖉𝖎𝖆𝖓𝖙", "⚜️ 𝕹𝖔𝖇𝖑𝖊", "💫 𝕾𝖚𝖕𝖗𝖊̀𝖒𝖊"
        ];

        // Get 3-5 random traits
        const numTraits = Math.floor(Math.random() * 3) + 3; // Random number between 3 and 5
        const selectedTraits = [];
        for (let i = 0; i < numTraits; i++) {
            const randomTrait = traits[Math.floor(Math.random() * traits.length)];
            if (!selectedTraits.includes(randomTrait)) {
                selectedTraits.push(randomTrait);
            }
        }

        // Calculate random percentages for each trait
        const traitPercentages = selectedTraits.map(trait => {
            const percentage = Math.floor(Math.random() * 41) + 60; // Random number between 60-100
            return `${trait}: ${percentage}%`;
        });

        // Create character analysis message
        const analysis = `☀️ *𝗔𝗡𝗔𝗟𝗬𝗦𝗘 𝗗𝗨 𝗟𝗜𝗢𝗡* ☀️\n\n` +
            `👤 *Mortel:* ${userToAnalyze.split('@')[0]}\n\n` +
            `✨ *𝗧𝗿𝗮𝗶𝘁𝘀 𝗱𝗲́𝘁𝗲𝗰𝘁𝗲́𝘀:*\n${traitPercentages.join('\n')}\n\n` +
            `🎯 *𝗣𝘂𝗶𝘀𝘀𝗮𝗻𝗰𝗲 𝗮𝗯𝘀𝗼𝗹𝘂𝗲:* ${Math.floor(Math.random() * 21) + 80}%\n\n` +
            `☀️ *Note du Lion:* Cette analyse révèle ta véritable essence, mortel. Ne la prends pas à la légère, car le Lion voit clair en toi. ☀️`;

        // Send the analysis with the user's profile picture
        await sock.sendMessage(chatId, {
            image: { url: profilePic },
            caption: analysis,
            mentions: [userToAnalyze],
            ...channelInfo
        });

    } catch (error) {
        console.error('☀️ Erreur dans la commande character:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE L\'ANALYSE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            ...channelInfo 
        });
    }
}

module.exports = characterCommand;