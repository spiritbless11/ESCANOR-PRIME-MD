async function unmuteCommand(sock, chatId) {
    await sock.groupSettingUpdate(chatId, 'not_announcement');
    await sock.sendMessage(chatId, { text: '☀️ *GROUPE RÉACTIVÉ* ☀️\nLes mortels peuvent à nouveau parler. Le Lion leur rend la parole.' });
}

module.exports = unmuteCommand;