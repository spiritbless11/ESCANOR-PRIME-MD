const { isAdmin } = require('../lib/isAdmin');

async function promoteCommand(sock, chatId, mentionedJids, message) {
    let userToPromote = [];
    
    if (mentionedJids && mentionedJids.length > 0) {
        userToPromote = mentionedJids;
    }
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToPromote = [message.message.extendedTextMessage.contextInfo.participant];
    }
    
    if (userToPromote.length === 0) {
        await sock.sendMessage(chatId, { 
            text: '☀️ *DÉSIGNE LE MORTEL À PROMOUVOIR.* ☀️\nMentionne-le ou réponds à son message.'
        });
        return;
    }

    try {
        await sock.groupParticipantsUpdate(chatId, userToPromote, "promote");
        
        const usernames = await Promise.all(userToPromote.map(async jid => {
            return `@${jid.split('@')[0]}`;
        }));

        const promotionMessage = `
☀️ *PROMOTION – LE LION ÉLÈVE UN MORTEL* ☀️

👤 *Promu${userToPromote.length > 1 ? 's' : ''}:*
${usernames.map(name => `┃ ${name}`).join('\n')}

👑 *Par:* @${message.key.participant ? message.key.participant.split('@')[0] : message.key.remoteJid.split('@')[0]}

📅 *Date:* ${new Date().toLocaleString()}

☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        await sock.sendMessage(chatId, { 
            text: promotionMessage,
            mentions: [...userToPromote, message.key.participant || message.key.remoteJid]
        });
    } catch (error) {
        console.error('☀️ Erreur dans la commande promote:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA PROMOTION.* ☀️' });
    }
}

async function handlePromotionEvent(sock, groupId, participants, author) {
    try {
        if (!Array.isArray(participants) || participants.length === 0) {
            return;
        }

        const promotedUsernames = await Promise.all(participants.map(async jid => {
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());
            return `@${jidString.split('@')[0]}`;
        }));

        let promotedBy;
        let mentionList = participants.map(jid => {
            return typeof jid === 'string' ? jid : (jid.id || jid.toString());
        });

        if (author && author.length > 0) {
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            promotedBy = `@${authorJid.split('@')[0]}`;
            mentionList.push(authorJid);
        } else {
            promotedBy = 'Système';
        }

        const promotionMessage = `
☀️ *PROMOTION AUTOMATIQUE – LE LION VEILLE* ☀️

👤 *Promu${participants.length > 1 ? 's' : ''}:*
${promotedUsernames.map(name => `┃ ${name}`).join('\n')}

👑 *Par:* ${promotedBy}

📅 *Date:* ${new Date().toLocaleString()}

☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        await sock.sendMessage(groupId, {
            text: promotionMessage,
            mentions: mentionList
        });
    } catch (error) {
        console.error('☀️ Erreur lors de l\'événement de promotion:', error);
    }
}

module.exports = { promoteCommand, handlePromotionEvent };