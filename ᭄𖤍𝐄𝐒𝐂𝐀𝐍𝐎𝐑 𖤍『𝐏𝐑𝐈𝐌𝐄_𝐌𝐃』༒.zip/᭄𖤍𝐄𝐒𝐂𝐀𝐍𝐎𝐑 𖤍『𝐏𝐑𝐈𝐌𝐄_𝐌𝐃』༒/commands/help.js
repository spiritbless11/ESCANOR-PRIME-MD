const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
const tsh = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(message.chat ? { remoteJid: "status@broadcast" } : {})
    },
    message: {
        contactMessage: {
            displayName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
            vcard: `BEGIN:VCARD\nVERSION:1.0\nN:;ESCCANOR PRIME;;;\nFN:ESCCANOR PRIME\nitem1.TEL;waid=243989132098:243989132098\nitem1.X-ABLabel:Mobile\nitem2.EMAIL;type=INTERNET:blessdev@syshacked.com\nitem2.X-ABLabel:Email\nitem3.URL:https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K\nitem3.X-ABLabel:Chaîne\nEND:VCARD`
        }
    }
}
    const helpMessage = `
☀️ *ESCCANOR PRIME – LE LION DE L'ORGUEIL* ☀️

╭━━━〔 🔥 𝖒𝖊𝖓𝖚 𝖕𝖗𝖎𝖓𝖈𝖎𝖕𝖆𝖑 🔥 〕━━━╮
┃ 💀 .alive – Le Lion rugit
┃ 🏠 .menu – Ce menu
┃ 📡 .ping – Tester la connexion
┃ ⏱️ .runtime – Temps de fonctionnement
┃ 🔗 .repo – Lien du dépôt
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 👑 𝖈𝖔𝖒𝖒𝖆𝖓𝖉𝖊𝖘 𝖆𝖉𝖒𝖎𝖓 👑 〕━━━╮
┃ ⚔️ .promote – Élever un mortel
┃ ⬇️ .demote – Le faire redescendre
┃ 🚫 .kick – Expulser
┃ 🔇 .mute – Faire taire
┃ 🔊 .unmute – Redonner la parole
┃ 📢 .tagall – Mentionner tous
┃ 👻 .hidetag – Mention cachée
┃ 🛡️ .antilink – Bloquer les liens
┃ 📝 .setgdesc – Description du groupe
┃ ✏️ .setgname – Nom du groupe
┃ 🖼️ .setgpp – Photo du groupe
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 🧠 𝖎𝖓𝖙𝖊𝖑𝖑𝖎𝖌𝖊𝖓𝖈𝖊 𝖆𝖗𝖙𝖎𝖋𝖎𝖈𝖎𝖊𝖑𝖑𝖊 🤖 〕━━━╮
┃ 🤖 .gpt – GPT-4
┃ 🧠 .gemini – Gemini AI
┃ 🎨 .imagine – Générer une image
┃ 🔥 .flux – Génération avancée
┃ 🌊 .sora – Vidéo IA
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 🎨 𝖘𝖙𝖎𝖈𝖐𝖊𝖗𝖘 🖼️ 〕━━━╮
┃ 🖼️ .sticker – Créer un sticker
┃ 📸 .take – Voler un sticker
┃ 🔀 .emojimix – Mélanger des émojis
┃ 📷 .igs – Sticker Instagram
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 📥 𝖙𝖊́𝖑𝖊́𝖈𝖍𝖆𝖗𝖌𝖊𝖒𝖊𝖓𝖙𝖘 📥 〕━━━╮
┃ 🎵 .play – Musique
┃ 🎬 .video – Vidéo YouTube
┃ 🎶 .spotify – Spotify
┃ 📸 .instagram – Reel Instagram
┃ 🔵 .facebook – Vidéo Facebook
┃ 🎵 .tiktok – TikTok
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 🛠️ 𝖔𝖚𝖙𝖎𝖑𝖘 🔧 〕━━━╮
┃ 🔗 .shorturl – Raccourcir un lien
┃ 📱 .qrcode – QR code
┃ 📸 .ss – Capture d'écran
┃ 🌍 .translate – Traduction
┃ 🎲 .dice – Lancer de dé
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 🎮 𝖏𝖊𝖚𝖝 🕹️ 〕━━━╮
┃ ❌ .ttt – Tic-Tac-Toe
┃ 🔤 .hangman – Pendu
┃ ❓ .trivia – Quiz
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 ☀️ 𝖈𝖗𝖊́𝖆𝖙𝖊𝖚𝖗 👑 〕━━━╮
┃ 👑 *Maître Suprême :* ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒
┃ 📢 *Chaîne :* https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K
┃ 🔗 *Groupe :* https://chat.whatsapp.com/B5PZoLePELTLXzDkTboMno
╰━━━━━━━━━━━━━━━━━━━━╯

☀️ *"Je suis celui qui se tient au-dessus de tout."* ☀️
> © ESCANOR PRIME – Le Lion de l'Orgueil`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363419277738229@newsletter',
                        newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
                        serverMessageId: -1
                    }
                }
            },{ quoted: tsh });
        } else {
            console.error('☀️ Image du bot non trouvée:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363419277738229@newsletter',
                        newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande help:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;