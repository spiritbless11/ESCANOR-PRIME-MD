const fetch = require('node-fetch');

const BASE = 'https://api.shizo.top/pies';
const VALID_COUNTRIES = ['india','malaysia', 'thailand', 'china', 'indonesia', 'japan', 'korea', 'vietnam'];

async function fetchPiesImageBuffer(country) {
	const url = `${BASE}/${country}?apikey=shizo`;
	const res = await fetch(url);
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
	const contentType = res.headers.get('content-type') || '';
	if (!contentType.includes('image')) throw new Error('API did not return an image');
	return res.buffer();
}

async function piesCommand(sock, chatId, message, args) {
	const sub = (args && args[0] ? args[0] : '').toLowerCase();
	if (!sub) {
		await sock.sendMessage(chatId, { text: `☀️ *UTILISATION:* .pies <pays>\nPays: ${VALID_COUNTRIES.join(', ')}` }, { quoted: message });
		return;
	}
	if (!VALID_COUNTRIES.includes(sub)) {
		await sock.sendMessage(chatId, { text: `☀️ *PAYS NON SUPPORTÉ:* ${sub}\nEssaie: ${VALID_COUNTRIES.join(', ')}` }, { quoted: message });
		return;
	}
	try {
		const imageBuffer = await fetchPiesImageBuffer(sub);
		await sock.sendMessage(
			chatId,
			{ image: imageBuffer, caption: `☀️ *PIES - ${sub.toUpperCase()}* ☀️` },
			{ quoted: message }
		);
	} catch (err) {
		console.error('☀️ Erreur dans la commande pies:', err);
		await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' }, { quoted: message });
	}
}

async function piesAlias(sock, chatId, message, country) {
	try {
		const imageBuffer = await fetchPiesImageBuffer(country);
		await sock.sendMessage(
			chatId,
			{ image: imageBuffer, caption: `☀️ *PIES - ${country.toUpperCase()}* ☀️` },
			{ quoted: message }
		);
	} catch (err) {
		console.error(`☀️ Erreur dans pies alias (${country}):`, err);
		await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️' }, { quoted: message });
	}
}

module.exports = { piesCommand, piesAlias, VALID_COUNTRIES };