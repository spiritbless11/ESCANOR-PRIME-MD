const TicTacToe = require('../lib/tictactoe');

const games = {};

async function tictactoeCommand(sock, chatId, senderId, text) {
    try {
        if (Object.values(games).find(room => 
            room.id.startsWith('tictactoe') && 
            [room.game.playerX, room.game.playerO].includes(senderId)
        )) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *TU ES DÉJÀ DANS UNE PARTIE.* ☀️\nTape *surrender* pour abandonner, mortel.' 
            });
            return;
        }

        let room = Object.values(games).find(room => 
            room.state === 'WAITING' && 
            (text ? room.name === text : true)
        );

        if (room) {
            room.o = chatId;
            room.game.playerO = senderId;
            room.state = 'PLAYING';

            const arr = room.game.render().map(v => ({
                'X': '❎',
                'O': '⭕',
                '1': '1️⃣',
                '2': '2️⃣',
                '3': '3️⃣',
                '4': '4️⃣',
                '5': '5️⃣',
                '6': '6️⃣',
                '7': '7️⃣',
                '8': '8️⃣',
                '9': '9️⃣',
            }[v]));

            const str = `
☀️ *TIC-TAC-TOE – LE LION VOUS DÉFIE* ☀️

Au tour de @${room.game.currentTurn.split('@')[0]}...

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ *ID:* ${room.id}
▢ *Règles:*
• Alignez 3 symboles pour gagner
• Tapez un nombre (1-9) pour jouer
• Tapez *surrender* pour abandonner
`;

            await sock.sendMessage(chatId, { 
                text: str,
                mentions: [room.game.currentTurn, room.game.playerX, room.game.playerO]
            });

        } else {
            room = {
                id: 'tictactoe-' + (+new Date),
                x: chatId,
                o: '',
                game: new TicTacToe(senderId, 'o'),
                state: 'WAITING'
            };

            if (text) room.name = text;

            await sock.sendMessage(chatId, { 
                text: `☀️ *EN ATTENTE D'UN ADVERSAIRE* ☀️\nTapez *.ttt ${text || ''}* pour relever le défi du Lion !`
            });

            games[room.id] = room;
        }

    } catch (error) {
        console.error('☀️ Erreur tictactoe:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DU DÉMARRAGE.* ☀️\nMême le Lion peut avoir un hoquet.' 
        });
    }
}

async function handleTicTacToeMove(sock, chatId, senderId, text) {
    try {
        const room = Object.values(games).find(room => 
            room.id.startsWith('tictactoe') && 
            [room.game.playerX, room.game.playerO].includes(senderId) && 
            room.state === 'PLAYING'
        );

        if (!room) return;

        const isSurrender = /^(surrender|give up)$/i.test(text);
        
        if (!isSurrender && !/^[1-9]$/.test(text)) return;

        if (senderId !== room.game.currentTurn && !isSurrender) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *CE N'EST PAS TON TOUR, MORTEL.* ☀️' 
            });
            return;
        }

        let ok = isSurrender ? true : room.game.turn(
            senderId === room.game.playerO,
            parseInt(text) - 1
        );

        if (!ok) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *COUP INVALIDE.* ☀️\nCette case est déjà prise.' 
            });
            return;
        }

        let winner = room.game.winner;
        let isTie = room.game.turns === 9;

        const arr = room.game.render().map(v => ({
            'X': '❎',
            'O': '⭕',
            '1': '1️⃣',
            '2': '2️⃣',
            '3': '3️⃣',
            '4': '4️⃣',
            '5': '5️⃣',
            '6': '6️⃣',
            '7': '7️⃣',
            '8': '8️⃣',
            '9': '9️⃣',
        }[v]));

        if (isSurrender) {
            winner = senderId === room.game.playerX ? room.game.playerO : room.game.playerX;
            
            await sock.sendMessage(chatId, { 
                text: `☀️ *ABANDON !* ☀️\n@${senderId.split('@')[0]} a abandonné. @${winner.split('@')[0]} remporte la partie !`,
                mentions: [senderId, winner]
            });
            
            delete games[room.id];
            return;
        }

        let gameStatus;
        if (winner) {
            gameStatus = `☀️ *VICTOIRE !* ☀️\n@${winner.split('@')[0]} remporte la partie !`;
        } else if (isTie) {
            gameStatus = `☀️ *MATCH NUL* ☀️\nLe Lion reconnaît l'égalité.`;
        } else {
            gameStatus = `☀️ *TOUR* ☀️\n@${room.game.currentTurn.split('@')[0]} (${senderId === room.game.playerX ? '❎' : '⭕'})`;
        }

        const str = `
☀️ *TIC-TAC-TOE* ☀️

${gameStatus}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ ❎: @${room.game.playerX.split('@')[0]}
▢ ⭕: @${room.game.playerO.split('@')[0]}

${!winner && !isTie ? '• Tapez un nombre (1-9) pour jouer\n• Tapez *surrender* pour abandonner' : ''}
`;

        const mentions = [
            room.game.playerX, 
            room.game.playerO,
            ...(winner ? [winner] : [room.game.currentTurn])
        ];

        await sock.sendMessage(room.x, { 
            text: str,
            mentions: mentions
        });

        if (room.x !== room.o) {
            await sock.sendMessage(room.o, { 
                text: str,
                mentions: mentions
            });
        }

        if (winner || isTie) {
            delete games[room.id];
        }

    } catch (error) {
        console.error('☀️ Erreur tictactoe move:', error);
    }
}

module.exports = {
    tictactoeCommand,
    handleTicTacToeMove
};