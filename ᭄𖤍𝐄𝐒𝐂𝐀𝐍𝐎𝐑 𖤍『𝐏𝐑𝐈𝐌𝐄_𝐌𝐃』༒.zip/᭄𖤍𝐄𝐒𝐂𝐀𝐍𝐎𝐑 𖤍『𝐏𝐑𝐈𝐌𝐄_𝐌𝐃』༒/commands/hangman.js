const fs = require('fs');

const words = ['javascript', 'bot', 'hangman', 'whatsapp', 'nodejs', 'escanor', 'lion', 'pride', 'sun'];
let hangmanGames = {};

function startHangman(sock, chatId) {
    const word = words[Math.floor(Math.random() * words.length)];
    const maskedWord = '_ '.repeat(word.length).trim();

    hangmanGames[chatId] = {
        word,
        maskedWord: maskedWord.split(' '),
        guessedLetters: [],
        wrongGuesses: 0,
        maxWrongGuesses: 6,
    };

    sock.sendMessage(chatId, { text: `☀️ *JEU DU PENDU – LE LION TE DÉFIE* ☀️\n\nMot: ${maskedWord}\n\nTrouve les lettres, mortel.` });
}

function guessLetter(sock, chatId, letter) {
    if (!hangmanGames[chatId]) {
        sock.sendMessage(chatId, { text: '☀️ *AUCUNE PARTIE EN COURS.* ☀️\nUtilise .hangman pour commencer.' });
        return;
    }

    const game = hangmanGames[chatId];
    const { word, guessedLetters, maskedWord, maxWrongGuesses } = game;

    if (guessedLetters.includes(letter)) {
        sock.sendMessage(chatId, { text: `☀️ *TU AS DÉJÀ PROPOSÉ "${letter}".* ☀️\nLe Lion n'aime pas les répétitions.` });
        return;
    }

    guessedLetters.push(letter);

    if (word.includes(letter)) {
        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter) {
                maskedWord[i] = letter;
            }
        }
        sock.sendMessage(chatId, { text: `☀️ *BONNE LETTRE, MORTEL.* ☀️\n${maskedWord.join(' ')}` });

        if (!maskedWord.includes('_')) {
            sock.sendMessage(chatId, { text: `☀️ *FÉLICITATIONS !* ☀️\nTu as trouvé le mot: ${word}\nLe Lion te reconnaît... pour l'instant.` });
            delete hangmanGames[chatId];
        }
    } else {
        game.wrongGuesses += 1;
        sock.sendMessage(chatId, { text: `☀️ *MAUVAISE LETTRE.* ☀️\nIl te reste ${maxWrongGuesses - game.wrongGuesses} essais.` });

        if (game.wrongGuesses >= maxWrongGuesses) {
            sock.sendMessage(chatId, { text: `☀️ *GAME OVER !* ☀️\nLe mot était: ${word}\nLe Lion te rappelle que la fierté ne suffit pas toujours.` });
            delete hangmanGames[chatId];
        }
    }
}

module.exports = { startHangman, guessLetter };