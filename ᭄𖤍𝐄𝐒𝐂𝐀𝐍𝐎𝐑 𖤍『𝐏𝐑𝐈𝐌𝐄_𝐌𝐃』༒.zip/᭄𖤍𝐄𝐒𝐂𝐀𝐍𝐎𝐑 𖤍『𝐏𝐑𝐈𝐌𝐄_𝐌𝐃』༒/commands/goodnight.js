const fetch = require('node-fetch');

async function goodnightCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/lovenight?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const goodnightMessage = json.result;

        await sock.sendMessage(chatId, { text: `☀️ *BONNE NUIT, MORTEL* ☀️\n\n${goodnightMessage}\n\n🔥 *Le Lion se retire. Que la fierté te guide.* 🔥` }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans la commande goodnight:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU MESSAGE DE BONNE NUIT.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' }, { quoted: message });
    }
}

module.exports = { goodnightCommand };