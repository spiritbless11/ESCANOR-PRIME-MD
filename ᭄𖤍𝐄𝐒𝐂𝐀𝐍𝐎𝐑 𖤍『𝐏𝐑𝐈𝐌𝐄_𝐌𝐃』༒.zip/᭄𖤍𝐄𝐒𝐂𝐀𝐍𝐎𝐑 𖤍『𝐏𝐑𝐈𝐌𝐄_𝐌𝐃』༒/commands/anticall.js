const fs = require('fs');

const ANTICALL_PATH = './data/anticall.json';

function readState() {
    try {
        if (!fs.existsSync(ANTICALL_PATH)) return { enabled: false };
        const raw = fs.readFileSync(ANTICALL_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');
        return { enabled: !!data.enabled };
    } catch {
        return { enabled: false };
    }
}

function writeState(enabled) {
    try {
        if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
        fs.writeFileSync(ANTICALL_PATH, JSON.stringify({ enabled: !!enabled }, null, 2));
    } catch {}
}

async function anticallCommand(sock, chatId, message, args) {
    const state = readState();
    const sub = (args || '').trim().toLowerCase();

    if (!sub || (sub !== 'on' && sub !== 'off' && sub !== 'status')) {
        await sock.sendMessage(chatId, { text: '☀️ *ANTICALL – LA PROTECTION DU LION* ☀️\n\n.anticall on  - Activer le blocage automatique des appels\n.anticall off - Désactiver l\'anticall\n.anticall status - Voir l\'état actuel' }, { quoted: message });
        return;
    }

    if (sub === 'status') {
        await sock.sendMessage(chatId, { text: `☀️ *ÉTAT DE L'ANTICALL* ☀️\n\nLa protection du Lion est actuellement *${state.enabled ? 'ACTIVÉE' : 'DÉSACTIVÉE'}*.` }, { quoted: message });
        return;
    }

    const enable = sub === 'on';
    writeState(enable);
    await sock.sendMessage(chatId, { text: `☀️ *ANTICALL* ☀️\n\nLa protection du Lion est désormais *${enable ? 'ACTIVÉE' : 'DÉSACTIVÉE'}*. ${enable ? 'Que les mortels téméraires tremblent.' : 'Le Lion baisse sa garde... pour l\'instant.'}` }, { quoted: message });
}

module.exports = { anticallCommand, readState };