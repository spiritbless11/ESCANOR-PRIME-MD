const fs = require('fs');
const settings = require("../settings");

// 🔹 NEWSLETTER - La chaîne du Lion
const NEWSLETTER = {
    jid: '120363419277738229@newsletter',
    name: '☀️ ༒ ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒ ☀️'   
};

// 🔹 IMAGE DU BOT - La fierté du Lion
const BOT_IMAGE = './assets/sticktag.webp';

// 🔹 DÉCOR MODIFIABLE - Le rugissement du Lion
const DECOR = `
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ ☀️ *𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𝐏𝐑𝐈𝐌𝐄 𝐄𝐒𝐓 𝐀𝐂𝐓𝐈𝐅* ☀️
┃                               
┃ ⚔️ 𝖁𝖊𝖗𝖘𝖎𝖔𝖓 : ${settings.version}          
┃ ☀️ 𝕾𝖙𝖆𝖙𝖚𝖘  : 𝕷𝖊 𝕷𝖎𝖔𝖓 𝖁𝖊𝖎𝖑𝖑𝖊 🔥        
┃ 👑 𝕸𝖔𝖉𝖊    : 𝕻𝖚𝖇𝖑𝖎𝖈 ⚔️     
┃                               
┃ 🔥 *𝕱𝖊𝖆𝖙𝖚𝖗𝖊𝖘 𝖉𝖚 𝕷𝖎𝖔𝖓* :          
┃ • ⚔️ 𝕲𝖊𝖘𝖙𝖎𝖔𝖓 𝖉𝖊𝖘 𝕲𝖗𝖔𝖚𝖕𝖊𝖘    
┃ • 🛡️ 𝕻𝖗𝖔𝖙𝖊𝖈𝖙𝖎𝖔𝖓 𝕬𝖓𝖙𝖎𝖑𝖎𝖊𝖓𝖘   
┃ • ☀️ 𝕮𝖔𝖒𝖒𝖆𝖓𝖉𝖊𝖘 𝕻𝖚𝖎𝖘𝖘𝖆𝖓𝖙𝖊𝖘     
┃ • 🔥 𝕰𝖙 𝖇𝖎𝖊𝖓 𝖕𝖑𝖚𝖘 𝖊𝖓𝖈𝖔𝖗𝖊 ✨           
┃                               
┃ ☀️ *𝕰́𝕮𝕺𝖀𝕿𝕰, 𝕸𝕺𝕽𝕿𝕰𝕷.* ☀️
┃ 𝕿𝖚 𝖛𝖎𝖊𝖓𝖘 𝖉𝖊 𝖗𝖊́𝖛𝖊́𝖑𝖊𝖗 𝖑𝖊 𝕷𝖎𝖔𝖓.
┃ 𝕻𝖚𝖎𝖘𝖘𝖆𝖓𝖈𝖊 𝖆𝖇𝖘𝖔𝖑𝖚𝖊, 𝖋𝖎𝖊𝖗𝖙𝖊́ 𝖘𝖆𝖓𝖘 𝖑𝖎𝖒𝖎𝖙𝖊.
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
> ☀️ 𝖕𝖔𝖜𝖊𝖗𝖊𝖉 𝖇𝖞  ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒ ☀️
`;

async function aliveCommand(sock, chatId, message) {
    try {
        await sock.sendMessage(chatId, {
            image: fs.readFileSync(BOT_IMAGE),
            caption: DECOR,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: NEWSLETTER.jid,
                    newsletterName: NEWSLETTER.name,
                    serverMessageId: 1
                }
            }
        }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans la commande alive:', error);
        await sock.sendMessage(chatId, { text: '☀️ *𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𝐏𝐑𝐈𝐌𝐄 𝐄𝐒𝐓 𝐕𝐈𝐕𝐀𝐍𝐓 𝐄𝐓 𝐏𝐔𝐈𝐒𝐒𝐀𝐍𝐓 !* ☀️' }, { quoted: message });
    }
}

module.exports = aliveCommand;