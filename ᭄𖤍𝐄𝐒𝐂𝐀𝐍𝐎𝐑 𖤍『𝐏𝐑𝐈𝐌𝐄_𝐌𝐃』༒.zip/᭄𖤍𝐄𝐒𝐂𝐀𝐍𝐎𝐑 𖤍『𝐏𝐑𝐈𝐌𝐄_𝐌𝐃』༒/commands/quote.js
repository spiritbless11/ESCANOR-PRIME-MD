const fetch = require('node-fetch');

module.exports = async function quoteCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/quotes?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const quoteMessage = json.result;

        await sock.sendMessage(chatId, { text: `☀️ *CITATION DU LION* ☀️\n\n${quoteMessage}` }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans la commande quote:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' }, { quoted: message });
    }
};