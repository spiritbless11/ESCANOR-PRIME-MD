const axios = require('axios');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { uploadImage } = require('../lib/uploadImage');

async function getQuotedOrOwnImageUrl(sock, message) {
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (quoted?.imageMessage) {
        const stream = await downloadContentFromMessage(quoted.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    if (message.message?.imageMessage) {
        const stream = await downloadContentFromMessage(message.message.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    return null;
}

async function reminiCommand(sock, chatId, message, args) {
    try {
        let imageUrl = null;
        
        if (args.length > 0) {
            const url = args.join(' ');
            if (isValidUrl(url)) {
                imageUrl = url;
            } else {
                return sock.sendMessage(chatId, { 
                    text: '☀️ *URL INVALIDE.* ☀️\n\nUtilisation: .remini https://exemple.com/image.jpg' 
                }, { quoted: message });
            }
        } else {
            imageUrl = await getQuotedOrOwnImageUrl(sock, message);
            
            if (!imageUrl) {
                return sock.sendMessage(chatId, { 
                    text: '☀️ *COMMANDE REMINI* ☀️\n\nUtilisation:\n• `.remini <url_image>`\n• Réponds à une image avec `.remini`\n• Envoie une image avec `.remini`' 
                }, { quoted: message });
            }
        }

        const apiUrl = `https://api.princetechn.com/api/tools/remini?apikey=prince_tech_api_azfsbshfb&url=${encodeURIComponent(imageUrl)}`;
        
        const response = await axios.get(apiUrl, {
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        if (response.data && response.data.success && response.data.result) {
            const result = response.data.result;
            
            if (result.image_url) {
                const imageResponse = await axios.get(result.image_url, {
                    responseType: 'arraybuffer',
                    timeout: 30000
                });
                
                if (imageResponse.status === 200 && imageResponse.data) {
                    await sock.sendMessage(chatId, {
                        image: imageResponse.data,
                        caption: '☀️ *IMAGE AMÉLIORÉE PAR LE LION* ☀️'
                    }, { quoted: message });
                } else {
                    throw new Error('Failed to download enhanced image');
                }
            } else {
                throw new Error(result.message || 'Failed to enhance image');
            }
        } else {
            throw new Error('API returned invalid response');
        }

    } catch (error) {
        console.error('☀️ Erreur Remini:', error.message);
        
        let errorMessage = '☀️ *ÉCHEC DE L\'AMÉLIORATION.* ☀️';
        
        if (error.response?.status === 429) {
            errorMessage = '☀️ *TROP DE DEMANDES.* ☀️\nRéessaie plus tard, mortel.';
        } else if (error.response?.status === 400) {
            errorMessage = '☀️ *URL INVALIDE.* ☀️';
        } else if (error.response?.status === 500) {
            errorMessage = '☀️ *ERREUR SERVEUR.* ☀️\nRéessaie plus tard.';
        } else if (error.code === 'ECONNABORTED') {
            errorMessage = '☀️ *TIMEOUT.* ☀️\nRéessaie, mortel.';
        } else if (error.message.includes('ENOTFOUND') || error.message.includes('ECONNREFUSED')) {
            errorMessage = '☀️ *ERREUR RÉSEAU.* ☀️\nVérifie ta connexion.';
        }
        
        await sock.sendMessage(chatId, { 
            text: errorMessage 
        }, { quoted: message });
    }
}

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

module.exports = { reminiCommand };