const fetch = require('node-fetch');

async function handleSsCommand(sock, chatId, message, match) {
    if (!match) {
        await sock.sendMessage(chatId, {
            text: `☀️ *CAPTURE D'ÉCRAN* ☀️\n\n.ss <url>\n.ssweb <url>\n.screenshot <url>\n\nCapture d'écran de n'importe quel site\n\nExemple:\n.ss https://google.com`,
            quoted: message
        });
        return;
    }

    try {
        await sock.presenceSubscribe(chatId);
        await sock.sendPresenceUpdate('composing', chatId);

        const url = match.trim();
        
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            return sock.sendMessage(chatId, {
                text: '☀️ *URL INVALIDE.* ☀️\nDoit commencer par http:// ou https://',
                quoted: message
            });
        }

        const apiUrl = `https://api.siputzx.my.id/api/tools/ssweb?url=${encodeURIComponent(url)}&theme=light&device=desktop`;
        const response = await fetch(apiUrl, { headers: { 'accept': '*/*' } });
        
        if (!response.ok) {
            throw new Error(`API responded with status: ${response.status}`);
        }

        const imageBuffer = await response.buffer();

        await sock.sendMessage(chatId, {
            image: imageBuffer,
            caption: `☀️ *CAPTURE DU SITE* ☀️\n${url}`
        }, {
            quoted: message
        });

    } catch (error) {
        console.error('☀️ Erreur dans ss:', error);
        await sock.sendMessage(chatId, {
            text: '☀️ *ÉCHEC DE LA CAPTURE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            quoted: message
        });
    }
}

module.exports = {
    handleSsCommand
};