const insults = [
    "☀️ *Tu es comme un nuage. Quand tu disparais, c'est un beau jour.* ☀️",
    "🔥 *Tu apportes tant de joie à tout le monde... quand tu quittes la pièce.* 🔥",
    "⚔️ *Je serais d'accord avec toi, mais alors nous aurions tous les deux tort.* ⚔️",
    "☀️ *Tu n'es pas stupide, tu as juste une malchance chronique dans tes pensées.* ☀️",
    "🦁 *Tes secrets sont en sécurité avec moi. Je ne les écoute même pas.* 🦁",
    "🔥 *Tu es la preuve que même l'évolution prend parfois des pauses.* 🔥",
    "☀️ *Tu as quelque chose sur le menton... non, le troisième en partant du bas.* ☀️",
    "⚔️ *Tu es comme une mise à jour logicielle. À chaque fois que je te vois, je me demande si j'en ai vraiment besoin.* ⚔️",
    "🦁 *Tu apportes le bonheur à tout le monde... quand tu pars.* 🦁",
    "🔥 *Tu es comme une pièce de monnaie – à deux faces et sans grande valeur.* 🔥",
    "☀️ *Tu as quelque chose en tête... oh attends, jamais.* ☀️",
    "⚔️ *Tu es la raison pour laquelle ils mettent des instructions sur les bouteilles de shampoing.* ⚔️",
    "🦁 *Tu es comme un nuage. Toujours à flotter sans but réel.* 🦁",
    "🔥 *Tes blagues sont comme du lait périmé – aigres et difficiles à digérer.* 🔥",
    "☀️ *Tu es comme une bougie dans le vent... inutile quand ça devient sérieux.* ☀️",
    "🦁 *Tu as quelque chose d'unique – ta capacité à énerver tout le monde également.* 🦁",
    "⚔️ *Tu es comme un signal Wi-Fi – toujours faible quand on a le plus besoin de toi.* ⚔️",
    "🔥 *Tu es la preuve que tout le monde n'a pas besoin de filtre pour être désagréable.* 🔥",
    "☀️ *Ton énergie est comme un trou noir – elle aspire la vie de la pièce.* ☀️",
    "🦁 *Tu as le visage parfait pour la radio.* 🦁",
    "🔥 *Tu es comme un embouteillage – personne ne te veut, mais te voilà.* 🔥",
    "⚔️ *Tu es comme un crayon cassé – sans intérêt.* ⚔️",
    "☀️ *Tes idées sont si originales que je suis sûr de les avoir déjà entendues.* ☀️",
    "🦁 *Tu es la preuve vivante que même les erreurs peuvent être productives.* 🦁",
    "🔥 *Tu n'es pas paresseux, tu es juste hautement motivé à ne rien faire.* 🔥"
];

async function insultCommand(sock, chatId, message) {
    try {
        if (!message || !chatId) {
            console.log('☀️ Message ou chatId invalide:', { message, chatId });
            return;
        }

        let userToInsult;
        
        // Check for mentioned users
        if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            userToInsult = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }
        // Check for replied message
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToInsult = message.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!userToInsult) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *DÉSIGNE LE MORTEL QUE TU VEUX INSULTER.* ☀️\nMentionne-le ou réponds à son message.'
            });
            return;
        }

        const insult = insults[Math.floor(Math.random() * insults.length)];

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.sendMessage(chatId, { 
            text: `☀️ *ÉCOUTE, MORTEL* ☀️\n@${userToInsult.split('@')[0]}, ${insult}`,
            mentions: [userToInsult]
        });
    } catch (error) {
        console.error('☀️ Erreur dans la commande insult:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *TROP DE DEMANDES.* ☀️\nLe Lion a besoin de souffler. Réessaie dans quelques instants.'
                });
            } catch (retryError) {
                console.error('☀️ Erreur d\'envoi du message d\'attente:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.'
                });
            } catch (sendError) {
                console.error('☀️ Erreur d\'envoi du message d\'erreur:', sendError);
            }
        }
    }
}

module.exports = { insultCommand };