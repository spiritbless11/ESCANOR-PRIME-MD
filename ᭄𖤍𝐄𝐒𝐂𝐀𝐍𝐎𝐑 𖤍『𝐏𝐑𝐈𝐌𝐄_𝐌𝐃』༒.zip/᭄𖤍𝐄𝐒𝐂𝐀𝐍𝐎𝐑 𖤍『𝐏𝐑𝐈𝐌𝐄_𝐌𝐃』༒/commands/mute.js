const isAdmin = require('../lib/isAdmin');

async function muteCommand(sock, chatId, senderId, message, durationInMinutes) {
    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️' }, { quoted: message });
        return;
    }

    if (!isSenderAdmin) {
        await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT MUTER.* ☀️' }, { quoted: message });
        return;
    }

    try {
        // Mute the group
        await sock.groupSettingUpdate(chatId, 'announcement');
        
        if (durationInMinutes !== undefined && durationInMinutes > 0) {
            const durationInMilliseconds = durationInMinutes * 60 * 1000;
            await sock.sendMessage(chatId, { text: `☀️ *GROUPE MUTÉ POUR ${durationInMinutes} MINUTES* ☀️\nQue le silence règne.` }, { quoted: message });
            
            // Set timeout to unmute after duration
            setTimeout(async () => {
                try {
                    await sock.groupSettingUpdate(chatId, 'not_announcement');
                    await sock.sendMessage(chatId, { text: '☀️ *GROUPE RÉACTIVÉ* ☀️\nLes mortels peuvent à nouveau parler.' });
                } catch (unmuteError) {
                    console.error('☀️ Erreur lors de la réactivation:', unmuteError);
                }
            }, durationInMilliseconds);
        } else {
            await sock.sendMessage(chatId, { text: '☀️ *GROUPE MUTÉ* ☀️\nLe Lion impose le silence.' }, { quoted: message });
        }
    } catch (error) {
        console.error('☀️ Erreur lors du mute:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU MUTE.* ☀️\nMême le Lion peut avoir un hoquet.' }, { quoted: message });
    }
}

module.exports = muteCommand;