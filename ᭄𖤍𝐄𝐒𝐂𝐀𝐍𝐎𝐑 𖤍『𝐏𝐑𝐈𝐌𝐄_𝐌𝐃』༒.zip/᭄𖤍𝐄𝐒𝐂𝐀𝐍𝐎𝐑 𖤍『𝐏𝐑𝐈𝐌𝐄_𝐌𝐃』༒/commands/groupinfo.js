async function groupInfoCommand(sock, chatId, msg) {
    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        
        let pp;
        try {
            pp = await sock.profilePictureUrl(chatId, 'image');
        } catch {
            pp = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        const participants = groupMetadata.participants;
        const groupAdmins = participants.filter(p => p.admin);
        const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
        
        const owner = groupMetadata.owner || groupAdmins.find(p => p.admin === 'superadmin')?.id || chatId.split('-')[0] + '@s.whatsapp.net';

        const text = `
☀️ *INFORMATIONS DU GROUPE – LE LION VEILLE* ☀️

🆔 *ID:* ${groupMetadata.id}
📛 *Nom:* ${groupMetadata.subject}
👥 *Membres:* ${participants.length}
👑 *Propriétaire:* @${owner.split('@')[0]}

🛡️ *Admins:*
${listAdmin}

📝 *Description:*
${groupMetadata.desc?.toString() || 'Aucune description'}

🔥 *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;

        await sock.sendMessage(chatId, {
            image: { url: pp },
            caption: text,
            mentions: [...groupAdmins.map(v => v.id), owner]
        });

    } catch (error) {
        console.error('☀️ Erreur dans la commande groupinfo:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION DES INFOS.* ☀️' });
    }
}

module.exports = groupInfoCommand;