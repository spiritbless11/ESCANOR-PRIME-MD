const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

async function wastedCommand(sock, chatId, message) {
    let userToWaste;
    
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToWaste = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToWaste = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToWaste) {
        await sock.sendMessage(chatId, { 
            text: '☀️ *DÉSIGNE LE MORTEL À "RÉDUIRE À L'ÉTAT".* ☀️\nMentionne-le ou réponds à son message.', 
            ...channelInfo 
        }, { quoted: message });
        return;
    }

    try {
        let profilePic;
        try {
            profilePic = await sock.profilePictureUrl(userToWaste, 'image');
        } catch {
            profilePic = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        const wastedResponse = await axios.get(
            `https://some-random-api.com/canvas/overlay/wasted?avatar=${encodeURIComponent(profilePic)}`,
            { responseType: 'arraybuffer' }
        );

        await sock.sendMessage(chatId, {
            image: Buffer.from(wastedResponse.data),
            caption: `☀️ *RÉDUIT À L'ÉTAT* ☀️\n\n@${userToWaste.split('@')[0]} a été vaincu par le Lion.\n\n⚰️ *Rest in pieces, mortel.* ⚰️`,
            mentions: [userToWaste],
            ...channelInfo
        });

    } catch (error) {
        console.error('☀️ Erreur dans wasted:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE LA CRÉATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            ...channelInfo 
        }, { quoted: message });
    }
}

module.exports = wastedCommand;