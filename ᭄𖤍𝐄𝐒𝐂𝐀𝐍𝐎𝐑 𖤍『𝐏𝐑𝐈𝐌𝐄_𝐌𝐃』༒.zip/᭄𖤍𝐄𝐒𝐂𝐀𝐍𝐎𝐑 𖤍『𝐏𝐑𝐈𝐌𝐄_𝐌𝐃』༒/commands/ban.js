const fs = require('fs');
const { channelInfo } = require('../lib/messageConfig');
const isAdmin = require('../lib/isAdmin');
const { isSudo } = require('../lib/index');

async function banCommand(sock, chatId, message) {
    // Restrict in groups to admins; in private to owner/sudo
    const isGroup = chatId.endsWith('@g.us');
    if (isGroup) {
        const senderId = message.key.participant || message.key.remoteJid;
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️\nLe Lion ne peut pas punir sans les droits nécessaires.', ...channelInfo }, { quoted: message });
            return;
        }
        if (!isSenderAdmin && !message.key.fromMe) {
            await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT BANNIR.* ☀️\nTu n\'as pas le pouvoir de commander le Lion.', ...channelInfo }, { quoted: message });
            return;
        }
    } else {
        const senderId = message.key.participant || message.key.remoteJid;
        const senderIsSudo = await isSudo(senderId);
        if (!message.key.fromMe && !senderIsSudo) {
            await sock.sendMessage(chatId, { text: '☀️ *SEUL MON MAÎTRE PEUT BANNIR EN PRIVÉ.* ☀️', ...channelInfo }, { quoted: message });
            return;
        }
    }
    let userToBan;
    
    // Check for mentioned users
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToBan = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // Check for replied message
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToBan = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToBan) {
        await sock.sendMessage(chatId, { 
            text: '☀️ *DÉSIGNE LE MORTEL À BANNIR.* ☀️\nMentionne-le ou réponds à son message.', 
            ...channelInfo 
        });
        return;
    }

    // Prevent banning the bot itself
    try {
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        if (userToBan === botId || userToBan === botId.replace('@s.whatsapp.net', '@lid')) {
            await sock.sendMessage(chatId, { text: '☀️ *TU NE PEUX PAS BANNIR LE LION, MORTEL.* ☀️', ...channelInfo }, { quoted: message });
            return;
        }
    } catch {}

    try {
        // Add user to banned list
        const bannedUsers = JSON.parse(fs.readFileSync('./data/banned.json'));
        if (!bannedUsers.includes(userToBan)) {
            bannedUsers.push(userToBan);
            fs.writeFileSync('./data/banned.json', JSON.stringify(bannedUsers, null, 2));
            
            await sock.sendMessage(chatId, { 
                text: `☀️ *BANNI !* ☀️\n@${userToBan.split('@')[0]} a été banni par le Lion. Qu'il médite sur son erreur.`,
                mentions: [userToBan],
                ...channelInfo 
            });
        } else {
            await sock.sendMessage(chatId, { 
                text: `☀️ *DÉJÀ BANNI* ☀️\n@${userToBan.split('@')[0]} est déjà dans la liste des bannis.`,
                mentions: [userToBan],
                ...channelInfo 
            });
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande ban:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU BAN.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.', ...channelInfo });
    }
}

module.exports = banCommand;