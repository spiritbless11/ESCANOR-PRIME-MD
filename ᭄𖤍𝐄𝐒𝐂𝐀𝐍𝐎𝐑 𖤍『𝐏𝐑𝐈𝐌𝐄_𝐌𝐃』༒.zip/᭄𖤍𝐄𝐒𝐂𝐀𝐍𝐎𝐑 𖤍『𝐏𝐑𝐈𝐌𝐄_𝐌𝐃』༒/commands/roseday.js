const fetch = require('node-fetch');

async function rosedayCommand(sock, chatId, message) {
    try {
        const res = await fetch(`https://api.princetechn.com/api/fun/roseday?apikey=prince`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const rosedayMessage = json.result;

        await sock.sendMessage(chatId, { text: `☀️ *ROSE DAY – LE LION CÉLÈBRE* ☀️\n\n${rosedayMessage}` }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans roseday:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' }, { quoted: message });
    }
}

module.exports = { rosedayCommand };