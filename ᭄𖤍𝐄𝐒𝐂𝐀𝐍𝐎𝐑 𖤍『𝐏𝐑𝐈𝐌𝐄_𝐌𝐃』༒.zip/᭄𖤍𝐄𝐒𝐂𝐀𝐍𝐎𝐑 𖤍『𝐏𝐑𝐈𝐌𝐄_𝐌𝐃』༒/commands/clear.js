async function clearCommand(sock, chatId) {
    try {
        const message = await sock.sendMessage(chatId, { text: '☀️ *LE LION NETTOIE SA TANIÈRE...* ☀️' });
        const messageKey = message.key; // Get the key of the message the bot just sent
        
        // Now delete the bot's message
        await sock.sendMessage(chatId, { delete: messageKey });
        
    } catch (error) {
        console.error('☀️ Erreur lors du nettoyage:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU NETTOYAGE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' });
    }
}

module.exports = { clearCommand };