const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');
const sharp = require('sharp');

async function blurCommand(sock, chatId, message, quotedMessage) {
    try {
        let imageBuffer;
        
        if (quotedMessage) {
            if (!quotedMessage.imageMessage) {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *RÉPONDS À UNE IMAGE, MORTEL.* ☀️' 
                }, { quoted: message });
                return;
            }
            
            const quoted = {
                message: {
                    imageMessage: quotedMessage.imageMessage
                }
            };
            
            imageBuffer = await downloadMediaMessage(
                quoted,
                'buffer',
                { },
                { }
            );
        } else if (message.message?.imageMessage) {
            imageBuffer = await downloadMediaMessage(
                message,
                'buffer',
                { },
                { }
            );
        } else {
            await sock.sendMessage(chatId, { 
                text: '☀️ *RÉPONDS À UNE IMAGE OU ENVOIE-EN UNE AVEC .blur* ☀️' 
            }, { quoted: message });
            return;
        }

        const resizedImage = await sharp(imageBuffer)
            .resize(800, 800, {
                fit: 'inside',
                withoutEnlargement: true
            })
            .jpeg({ quality: 80 })
            .toBuffer();

        const blurredImage = await sharp(resizedImage)
            .blur(10)
            .toBuffer();

        await sock.sendMessage(chatId, {
            image: blurredImage,
            caption: '☀️ *IMAGE FLOUTÉE PAR LE LION* ☀️',
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363419277738229@newsletter',
                    newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
                    serverMessageId: -1
                }
            }
        }, { quoted: message });

    } catch (error) {
        console.error('☀️ Erreur dans la commande blur:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DU FLOU.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' 
        }, { quoted: message });
    }
}

module.exports = blurCommand;