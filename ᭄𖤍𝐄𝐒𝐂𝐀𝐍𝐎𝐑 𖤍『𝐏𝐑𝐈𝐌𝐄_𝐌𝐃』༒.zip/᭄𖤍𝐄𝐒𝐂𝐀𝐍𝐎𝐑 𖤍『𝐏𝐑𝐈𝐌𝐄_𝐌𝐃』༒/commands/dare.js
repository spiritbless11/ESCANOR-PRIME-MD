const fetch = require('node-fetch');

async function dareCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/dare?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const dareMessage = json.result;

        // Send the dare message
        await sock.sendMessage(chatId, { text: `☀️ *DÉFI DU LION* ☀️\n\n${dareMessage}` }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans la commande dare:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU DÉFI.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' }, { quoted: message });
    }
}

module.exports = { dareCommand };