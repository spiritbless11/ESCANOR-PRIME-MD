const isAdmin = require('../lib/isAdmin');

async function demoteCommand(sock, chatId, mentionedJids, message) {
    try {
        // First check if it's a group
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *CETTE COMMANDE N\'EST DISPONIBLE QU\'EN GROUPE.* ☀️'
            });
            return;
        }

        // Check admin status first, before any other operations
        try {
            const adminStatus = await isAdmin(sock, chatId, message.key.participant || message.key.remoteJid);
            
            if (!adminStatus.isBotAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️\nLe Lion ne peut pas rétrograder sans pouvoir.'
                });
                return;
            }

            if (!adminStatus.isSenderAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT RÉTROGRADER.* ☀️\nTu n\'as pas le pouvoir de commander le Lion.'
                });
                return;
            }
        } catch (adminError) {
            console.error('☀️ Erreur de vérification admin:', adminError);
            await sock.sendMessage(chatId, { 
                text: '☀️ *ERREUR : ASSUREZ-VOUS QUE LE LION EST ADMIN.* ☀️'
            });
            return;
        }

        let userToDemote = [];
        
        // Check for mentioned users
        if (mentionedJids && mentionedJids.length > 0) {
            userToDemote = mentionedJids;
        }
        // Check for replied message
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToDemote = [message.message.extendedTextMessage.contextInfo.participant];
        }
        
        // If no user found through either method
        if (userToDemote.length === 0) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *DÉSIGNE LE MORTEL À RÉTROGRADER.* ☀️\nMentionne-le ou réponds à son message.'
            });
            return;
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.groupParticipantsUpdate(chatId, userToDemote, "demote");
        
        // Get usernames for each demoted user
        const usernames = await Promise.all(userToDemote.map(async jid => {
            return `@${jid.split('@')[0]}`;
        }));

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        const demotionMessage = `
☀️ *𝗥𝗘́𝗧𝗥𝗢𝗚𝗥𝗔𝗗𝗔𝗧𝗜𝗢𝗡 – 𝗟𝗘 𝗟𝗜𝗢𝗡 𝗔 𝗣𝗔𝗥𝗟𝗘́* ☀️

👤 *Rétrogradé${userToDemote.length > 1 ? 's' : ''}:*
${usernames.map(name => `┃ ${name}`).join('\n')}

👑 *Par:* @${message.key.participant ? message.key.participant.split('@')[0] : message.key.remoteJid.split('@')[0]}

📅 *Date:* ${new Date().toLocaleString()}

> ☀️ ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒ ☀️`;
        
        await sock.sendMessage(chatId, { 
            text: demotionMessage,
            mentions: [...userToDemote, message.key.participant || message.key.remoteJid]
        });
    } catch (error) {
        console.error('☀️ Erreur dans la commande demote:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *TROP DE DEMANDES.* ☀️\nLe Lion a besoin de souffler. Réessaie dans quelques instants.'
                });
            } catch (retryError) {
                console.error('☀️ Erreur d\'envoi du message d\'attente:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *ÉCHEC DE LA RÉTROGRADATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.'
                });
            } catch (sendError) {
                console.error('☀️ Erreur d\'envoi du message d\'erreur:', sendError);
            }
        }
    }
}

// Function to handle automatic demotion detection
async function handleDemotionEvent(sock, groupId, participants, author) {
    try {
        // Safety check for participants
        if (!Array.isArray(participants) || participants.length === 0) {
            return;
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Get usernames for demoted participants
        const demotedUsernames = await Promise.all(participants.map(async jid => {
            // Handle case where jid might be an object or not a string
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());
            return `@${jidString.split('@')[0]}`;
        }));

        let demotedBy;
        let mentionList = participants.map(jid => {
            // Ensure all mentions are proper JID strings
            return typeof jid === 'string' ? jid : (jid.id || jid.toString());
        });

        if (author && author.length > 0) {
            // Ensure author has the correct format
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            demotedBy = `@${authorJid.split('@')[0]}`;
            mentionList.push(authorJid);
        } else {
            demotedBy = 'Système';
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        const demotionMessage = `
☀️ *𝗥𝗘́𝗧𝗥𝗢𝗚𝗥𝗔𝗗𝗔𝗧𝗜𝗢𝗡 𝗔𝗨𝗧𝗢𝗠𝗔𝗧𝗜𝗤𝗨𝗘 – 𝗟𝗘 𝗟𝗜𝗢𝗡 𝗩𝗘𝗜𝗟𝗟𝗘* ☀️

👤 *Rétrogradé${participants.length > 1 ? 's' : ''}:*
${demotedUsernames.map(name => `┃ ${name}`).join('\n')}

👑 *Par:* ${demotedBy}

📅 *Date:* ${new Date().toLocaleString()}

> ☀️ ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒ ☀️`;
        
        await sock.sendMessage(groupId, {
            text: demotionMessage,
            mentions: mentionList
        });
    } catch (error) {
        console.error('☀️ Erreur lors de l\'événement de rétrogradation:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }
}

module.exports = { demoteCommand, handleDemotionEvent };