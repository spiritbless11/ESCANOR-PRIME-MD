const fs = require('fs');
const path = require('path');
const os = require('os');
const isOwnerOrSudo = require('../lib/isOwner');

const channelInfo = {
    contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363419277738229@newsletter',
            newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
            serverMessageId: -1
        }
    }
};

async function clearSessionCommand(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SEUL MON MAÎTRE PEUT UTILISER CETTE COMMANDE.* ☀️\nLe Lion n\'obéit qu\'à celui qui l\'a dompté.',
                ...channelInfo
            });
            return;
        }

        // Define session directory
        const sessionDir = path.join(__dirname, '../session');

        if (!fs.existsSync(sessionDir)) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *DOSSIER SESSION INTROUVABLE.* ☀️\nLe Lion cherche sa tanière mais ne la trouve pas.',
                ...channelInfo
            });
            return;
        }

        let filesCleared = 0;
        let errors = 0;
        let errorDetails = [];

        // Send initial status
        await sock.sendMessage(chatId, { 
            text: `☀️ *LE LION OPTIMISE SA TANIÈRE...* ☀️\nNettoyage des fichiers de session en cours.`,
            ...channelInfo
        });

        const files = fs.readdirSync(sessionDir);
        
        // Count files by type for optimization
        let appStateSyncCount = 0;
        let preKeyCount = 0;

        for (const file of files) {
            if (file.startsWith('app-state-sync-')) appStateSyncCount++;
            if (file.startsWith('pre-key-')) preKeyCount++;
        }

        // Delete files
        for (const file of files) {
            if (file === 'creds.json') {
                // Skip creds.json file
                continue;
            }
            try {
                const filePath = path.join(sessionDir, file);
                fs.unlinkSync(filePath);
                filesCleared++;
            } catch (error) {
                errors++;
                errorDetails.push(`Échec de suppression de ${file}: ${error.message}`);
            }
        }

        // Send completion message
        const message = `☀️ *SESSION NETTOYÉE AVEC SUCCÈS !* ☀️\n\n` +
                       `📊 *Statistiques du Lion:*\n` +
                       `• Fichiers supprimés: ${filesCleared}\n` +
                       `• Fichiers sync app-state: ${appStateSyncCount}\n` +
                       `• Fichiers pre-key: ${preKeyCount}\n` +
                       (errors > 0 ? `\n⚠️ Erreurs rencontrées: ${errors}\n${errorDetails.join('\n')}` : '');

        await sock.sendMessage(chatId, { 
            text: message,
            ...channelInfo
        });

    } catch (error) {
        console.error('☀️ Erreur dans la commande clearsession:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DU NETTOYAGE DE LA SESSION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            ...channelInfo
        });
    }
}

module.exports = clearSessionCommand;