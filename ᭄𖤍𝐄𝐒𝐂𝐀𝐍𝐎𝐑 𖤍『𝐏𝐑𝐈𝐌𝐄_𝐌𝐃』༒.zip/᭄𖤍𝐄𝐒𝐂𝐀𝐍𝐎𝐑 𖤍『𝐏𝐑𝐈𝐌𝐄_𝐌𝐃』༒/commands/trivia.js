const axios = require('axios');

let triviaGames = {};

async function startTrivia(sock, chatId) {
    if (triviaGames[chatId]) {
        sock.sendMessage(chatId, { text: '☀️ *UNE PARTIE EST DÉJÀ EN COURS.* ☀️' });
        return;
    }

    try {
        const response = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple');
        const questionData = response.data.results[0];

        triviaGames[chatId] = {
            question: questionData.question,
            correctAnswer: questionData.correct_answer,
            options: [...questionData.incorrect_answers, questionData.correct_answer].sort(),
        };

        sock.sendMessage(chatId, {
            text: `☀️ *QUIZ – LE LION TESTE TES CONNAISSANCES* ☀️\n\nQuestion: ${triviaGames[chatId].question}\nOptions:\n${triviaGames[chatId].options.join('\n')}`
        });
    } catch (error) {
        sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nRéessaie plus tard, mortel.' });
    }
}

function answerTrivia(sock, chatId, answer) {
    if (!triviaGames[chatId]) {
        sock.sendMessage(chatId, { text: '☀️ *AUCUNE PARTIE EN COURS.* ☀️' });
        return;
    }

    const game = triviaGames[chatId];

    if (answer.toLowerCase() === game.correctAnswer.toLowerCase()) {
        sock.sendMessage(chatId, { text: `☀️ *CORRECT !* ☀️\nLa réponse était ${game.correctAnswer}\nLe Lion te reconnaît... pour l'instant.` });
    } else {
        sock.sendMessage(chatId, { text: `☀️ *FAUX !* ☀️\nLa bonne réponse était ${game.correctAnswer}\nLe Lion te pardonne ton ignorance.` });
    }

    delete triviaGames[chatId];
}

module.exports = { startTrivia, answerTrivia };