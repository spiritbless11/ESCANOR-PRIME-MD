const yts = require('yt-search');
const axios = require('axios');

const PLAY_IMAGES = [
    'https://cdn-icons-png.flaticon.com/512/727/727218.png',
    'https://cdn-icons-png.flaticon.com/512/2995/2995101.png',
    'https://cdn-icons-png.flaticon.com/512/1384/1384060.png'
];

const getRandomImage = () => PLAY_IMAGES[Math.floor(Math.random() * PLAY_IMAGES.length)];

const NEWSLETTER_CONFIG = {
    newsletterJid: '120363419277738229@newsletter',
    newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
    serverMessageId: -1
};

function formatDuration(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatViews(views) {
    if (!views) return '0';
    if (views >= 1000000) return (views / 1000000).toFixed(1) + 'M';
    if (views >= 1000) return (views / 1000).toFixed(1) + 'K';
    return views.toString();
}

async function playCommand(sock, chatId, message) {
    try {
        const text =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            "";

        const searchQuery = text.split(' ').slice(1).join(' ').trim();

        if (!searchQuery) {
            return await sock.sendMessage(chatId, {
                image: { url: getRandomImage() },
                caption: `☀️ *UTILISATION:* .play <nom de la chanson ou lien YouTube>\n\nExemple: .play shape of you`,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: NEWSLETTER_CONFIG,
                    externalAdReply: {
                        title: "☀️ ESCANOR PRIME – MUSIQUE ☀️",
                        body: "Le Lion joue ta musique",
                        thumbnailUrl: getRandomImage(),
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        sourceUrl: "https://wa.me/243989132098"
                    }
                }
            }, { quoted: message });
        }

        const searchingMsg = await sock.sendMessage(chatId, {
            text: "☀️ *LE LION CHERCHE TA MUSIQUE...* ☀️"
        }, { quoted: message });

        const search = await yts(searchQuery);
        if (!search.videos || search.videos.length === 0) {
            return await sock.sendMessage(chatId, {
                image: { url: getRandomImage() },
                caption: "☀️ *AUCUNE MUSIQUE TROUVÉE.* ☀️\nEssaie d'autres mots-clés, mortel.",
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: NEWSLETTER_CONFIG
                }
            }, { quoted: message });
        }

        const video = search.videos[0];
        const videoUrl = video.url;

        const menuText = `
☀️ *ESCCANOR PRIME – LECTURE MUSICALE* ☀️

🎼 *Titre:* ${video.title}

⏱️ *Durée:* ${video.timestamp}
👤 *Artiste:* ${video.author.name}
👁️ *Vues:* ${formatViews(video.views)}
📅 *Publié:* ${video.ago}

☀️ *"Que la puissance du soleil guide ta musique"* ☀️

`;

        try {
            await sock.sendMessage(chatId, { delete: searchingMsg.key });
        } catch {}

        await sock.sendMessage(chatId, {
            image: { url: video.thumbnail },
            caption: menuText,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: NEWSLETTER_CONFIG,
                externalAdReply: {
                    title: "🎵 " + video.title.substring(0, 50),
                    body: `👤 ${video.author.name} | ⏱️ ${video.timestamp}`,
                    thumbnailUrl: video.thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    sourceUrl: videoUrl
                }
            }
        }, { quoted: message });

        const apiUrl = `https://yt-dl.officialhectormanuel.workers.dev/?url=${encodeURIComponent(videoUrl)}`;
        const { data } = await axios.get(apiUrl, { timeout: 15000 });

        if (!data?.status || !data?.audio) {
            return await sock.sendMessage(chatId, {
                image: { url: getRandomImage() },
                caption: "☀️ *IMPOSSIBLE DE RÉCUPÉRER L'AUDIO.* ☀️\nEssaie une autre chanson, mortel.",
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: NEWSLETTER_CONFIG
                }
            }, { quoted: message });
        }

        const audioResponse = await axios.get(data.audio, {
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Accept-Encoding': 'identity'
            }
        });

        const audioBuffer = Buffer.from(audioResponse.data);
        const safeTitle = (data.title || video.title || "audio")
            .replace(/[<>:"/\\|?*]+/g, '');

        const successText = `
☀️ *TÉLÉCHARGEMENT TERMINÉ, MORTEL !* ☀️

🎵 *${safeTitle}*
📦 *Format:* MP3 Audio
🔊 *Qualité:* Haute qualité

☀️ *Profite de ta musique. Le Lion te salue.* ☀️
`;

        await sock.sendMessage(chatId, {
            audio: audioBuffer,
            mimetype: "audio/mpeg",
            fileName: `${safeTitle}.mp3`,
            ptt: false,
            caption: successText,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: NEWSLETTER_CONFIG,
                externalAdReply: {
                    title: "🎵 " + safeTitle.substring(0, 50),
                    body: "☀️ Téléchargé par ESCANOR PRIME ☀️",
                    thumbnailUrl: video.thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    sourceUrl: "https://wa.me/243989132098"
                }
            }
        }, { quoted: message });

    } catch (error) {
        console.error('☀️ Erreur dans la commande play:', error);
        await sock.sendMessage(chatId, {
            image: { url: getRandomImage() },
            caption: "☀️ *ÉCHEC DU TÉLÉCHARGEMENT.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.",
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: NEWSLETTER_CONFIG
            }
        }, { quoted: message });
    }
}

module.exports = playCommand;