async function resetlinkCommand(sock, chatId, senderId) {
    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        const isAdmin = groupMetadata.participants
            .filter(p => p.admin)
            .map(p => p.id)
            .includes(senderId);

        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const isBotAdmin = groupMetadata.participants
            .filter(p => p.admin)
            .map(p => p.id)
            .includes(botId);

        if (!isAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT RÉINITIALISER LE LIEN.* ☀️' });
            return;
        }

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️' });
            return;
        }

        const newCode = await sock.groupRevokeInvite(chatId);
        
        await sock.sendMessage(chatId, { 
            text: `☀️ *LIEN DU GROUPE RÉINITIALISÉ* ☀️\n\n📌 Nouveau lien:\nhttps://chat.whatsapp.com/${newCode}`
        });

    } catch (error) {
        console.error('☀️ Erreur dans resetlink:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉINITIALISATION.* ☀️' });
    }
}

module.exports = resetlinkCommand;