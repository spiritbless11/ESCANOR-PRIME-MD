const fetch = require('node-fetch');

// --- Images par défaut si la photo de profil n'existe pas ---
const GOODBYE_IMAGES = [
    'https://image2url.com/r2/default/images/1773530266608-4ceb6e50-be36-4801-aef3-b0428ff1994e.jpg',
    'https://image2url.com/r2/default/images/1773529965777-b30329cf-14a0-4e2d-9a87-233170266ce7.jpg',
    'https://image2url.com/r2/default/images/1773530189483-53e36496-fc83-4f87-a41a-8d6ae80301f6.jpg'
];

// --- Statut Goodbye activé pour les groupes ---
const goodbyeStatus = {};

// --- Stylisation ---
function lionStyle(text) {
    return text.split('').map(c => c).join('');
}

// --- Activer / désactiver Goodbye ---
function setGoodbye(groupId, status) {
    goodbyeStatus[groupId] = !!status;
}

function isGoodbyeOn(groupId) {
    return !!goodbyeStatus[groupId];
}

// --- Fonction principale Goodbye ---
async function handleLeaveEvent(sock, chatId, participants) {
    if (!isGoodbyeOn(chatId)) return;

    const groupMetadata = await sock.groupMetadata(chatId);
    const groupName = groupMetadata.subject;
    const totalMembers = groupMetadata.participants.length;
    const totalAdmins = groupMetadata.participants.filter(p => p.admin).length;

    const newsletterJid = '120363419277738229@newsletter';

    for (const participant of participants) {
        try {
            const participantId = typeof participant === 'string' ? participant : participant.id || participant.toString();
            const userName = participantId.split('@')[0];

            let userPic;
            try {
                userPic = await sock.profilePictureUrl(participantId, 'image');
            } catch {
                userPic = GOODBYE_IMAGES[Math.floor(Math.random() * GOODBYE_IMAGES.length)];
            }

            const now = new Date();
            const time = now.toLocaleTimeString("fr-FR", { timeZone: "Africa/Douala" });
            const date = now.toLocaleDateString("fr-FR", { timeZone: "Africa/Douala" });

            const goodbyeMessage = `
☀️ *LE LION TE SALUE, MORTEL* ☀️

🦁 *Utilisateur :* @${userName}
👥 *Groupe :* ${groupName}
📊 *Membres restants :* ${totalMembers}
👑 *Admins :* ${totalAdmins}
⏰ *Heure :* ${time}
📅 *Date :* ${date}

🔥 *Puise ta fierté ailleurs. Le Lion ne te retient pas.* 🔥

☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;

            await sock.sendMessage(chatId, {
                image: { url: userPic },
                caption: goodbyeMessage,
                mentions: [participantId],
                contextInfo: {
                    mentionedJid: [participantId],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: newsletterJid,
                        newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
                        serverMessageId: Math.floor(Math.random() * 1000)
                    },
                    externalAdReply: {
                        title: '☀️ ESCANOR PRIME ☀️',
                        body: "Le Lion te regarde partir, mortel.",
                        thumbnailUrl: userPic,
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        sourceUrl: "https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K"
                    }
                }
            });

        } catch (error) {
            console.error('☀️ Erreur lors de l\'envoi du goodbye:', error);
        }
    }
}

// --- Commande pour activer/désactiver Goodbye ---
async function goodbyeCommand(sock, chatId, message) {
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: '☀️ *CETTE COMMANDE N\'EST DISPONIBLE QU\'EN GROUPE.* ☀️' });
        return;
    }

    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const args = text.trim().split(' ').slice(1);

    if (args[0]?.toLowerCase() === 'on') {
        setGoodbye(chatId, true);
        await sock.sendMessage(chatId, { text: '☀️ *MESSAGES DE DÉPART ACTIVÉS DANS CE GROUPE.* ☀️\nLe Lion te saluera au revoir.' });
    } else if (args[0]?.toLowerCase() === 'off') {
        setGoodbye(chatId, false);
        await sock.sendMessage(chatId, { text: '☀️ *MESSAGES DE DÉPART DÉSACTIVÉS DANS CE GROUPE.* ☀️\nLe Lion se tait.' });
    } else if (args[0]?.toLowerCase() === 'test') {
        await handleLeaveEvent(sock, chatId, [message.key?.participant]);
    } else {
        await sock.sendMessage(chatId, {
            text: '☀️ *COMMANDE GOODBYE* ☀️\n\n.goodbye on - Activer les messages de départ\n.goodbye off - Désactiver\n.goodbye test - Tester'
        });
    }
}

module.exports = { handleLeaveEvent, goodbyeCommand, setGoodbye, isGoodbyeOn };