const fetch = require('node-fetch');

async function stupidCommand(sock, chatId, quotedMsg, mentionedJid, sender, args) {
    try {
        let who = quotedMsg 
            ? quotedMsg.sender 
            : mentionedJid && mentionedJid[0] 
                ? mentionedJid[0] 
                : sender;

        let text = args && args.length > 0 ? args.join(' ') : 'im+stupid';
        
        let avatarUrl;
        try {
            avatarUrl = await sock.profilePictureUrl(who, 'image');
        } catch (error) {
            console.error('☀️ Erreur photo de profil:', error);
            avatarUrl = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';
        }

        const apiUrl = `https://some-random-api.com/canvas/misc/its-so-stupid?avatar=${encodeURIComponent(avatarUrl)}&dog=${encodeURIComponent(text)}`;
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`API responded with status: ${response.status}`);
        }

        const imageBuffer = await response.buffer();

        await sock.sendMessage(chatId, {
            image: imageBuffer,
            caption: `☀️ *@${who.split('@')[0]}* ☀️\nLe Lion a parlé.`,
            mentions: [who]
        });

    } catch (error) {
        console.error('☀️ Erreur stupid:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE LA GÉNÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.'
        });
    }
}

module.exports = { stupidCommand };