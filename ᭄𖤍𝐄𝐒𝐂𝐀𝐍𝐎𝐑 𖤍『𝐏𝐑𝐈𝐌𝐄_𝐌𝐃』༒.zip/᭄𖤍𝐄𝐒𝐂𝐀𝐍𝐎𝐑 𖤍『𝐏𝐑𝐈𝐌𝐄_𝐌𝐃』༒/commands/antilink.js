const { bots } = require('../lib/antilink');
const { setAntilink, getAntilink, removeAntilink } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');

async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message) {
    try {
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT GÉRER L\'ANTILINK.* ☀️\nLe Lion n\'obéit qu\'à ceux qui ont le pouvoir.' }, { quoted: message });
            return;
        }

        const prefix = '.';
        const args = userMessage.slice(9).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            const usage = `☀️ *ANTILINK – LA PROTECTION DU LION* ☀️\n\n${prefix}antilink on\n${prefix}antilink set delete | kick | warn\n${prefix}antilink off\n\n*Commande réservée aux administrateurs.*`;
            await sock.sendMessage(chatId, { text: usage }, { quoted: message });
            return;
        }

        switch (action) {
            case 'on':
                const existingConfig = await getAntilink(chatId, 'on');
                if (existingConfig?.enabled) {
                    await sock.sendMessage(chatId, { text: '☀️ *L\'ANTILINK EST DÉJÀ ACTIF.* ☀️' }, { quoted: message });
                    return;
                }
                const result = await setAntilink(chatId, 'on', 'delete');
                await sock.sendMessage(chatId, { 
                    text: result ? '☀️ *L\'ANTILINK EST MAINTENANT ACTIF.* ☀️\nQue les liens interdits tremblent.' : '☀️ *ÉCHEC DE L\'ACTIVATION DE L\'ANTILINK.* ☀️' 
                },{ quoted: message });
                break;

            case 'off':
                await removeAntilink(chatId, 'on');
                await sock.sendMessage(chatId, { text: '☀️ *L\'ANTILINK EST MAINTENANT DÉSACTIVÉ.* ☀️\nLe Lion baisse sa garde... pour l\'instant.' }, { quoted: message });
                break;

            case 'set':
                if (args.length < 2) {
                    await sock.sendMessage(chatId, { 
                        text: `☀️ *COMMANDE INCOMPLÈTE* ☀️\nUtilisation: ${prefix}antilink set delete | kick | warn` 
                    }, { quoted: message });
                    return;
                }
                const setAction = args[1];
                if (!['delete', 'kick', 'warn'].includes(setAction)) {
                    await sock.sendMessage(chatId, { 
                        text: '☀️ *ACTION INVALIDE.* ☀️\nChoisis: delete, kick, ou warn.' 
                    }, { quoted: message });
                    return;
                }
                const setResult = await setAntilink(chatId, 'on', setAction);
                await sock.sendMessage(chatId, { 
                    text: setResult ? `☀️ *ACTION ANTILINK DÉFINIE SUR : ${setAction.toUpperCase()}* ☀️` : '☀️ *ÉCHEC DE LA CONFIGURATION.* ☀️' 
                }, { quoted: message });
                break;

            case 'get':
                const status = await getAntilink(chatId, 'on');
                const actionConfig = await getAntilink(chatId, 'on');
                await sock.sendMessage(chatId, { 
                    text: `☀️ *CONFIGURATION ANTILINK* ☀️\n\nStatut: ${status ? 'ACTIF' : 'INACTIF'}\nAction: ${actionConfig ? actionConfig.action : 'Non définie'}` 
                }, { quoted: message });
                break;

            default:
                await sock.sendMessage(chatId, { text: `☀️ *Utilise ${prefix}antilink pour voir les options.* ☀️` });
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande antilink:', error);
        await sock.sendMessage(chatId, { text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' });
    }
}

async function handleLinkDetection(sock, chatId, message, userMessage, senderId) {
    const antilinkSetting = getAntilinkSetting(chatId);
    if (antilinkSetting === 'off') return;

    console.log(`☀️ Antilink pour ${chatId}: ${antilinkSetting}`);
    console.log(`☀️ Vérification du message: ${userMessage}`);
    
    // Log the full message object to diagnose message structure
    console.log("☀️ Message complet: ", JSON.stringify(message, null, 2));

    let shouldDelete = false;

    const linkPatterns = {
        whatsappGroup: /chat\.whatsapp\.com\/[A-Za-z0-9]{20,}/i,
        whatsappChannel: /wa\.me\/channel\/[A-Za-z0-9]{20,}/i,
        telegram: /t\.me\/[A-Za-z0-9_]+/i,
        // Matches:
        // - Full URLs with protocol (http/https)
        // - URLs starting with www.
        // - Bare domains anywhere in the string, even when attached to text
        //   e.g., "helloinstagram.comworld" or "testhttps://x.com"
        allLinks: /https?:\/\/\S+|www\.\S+|(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/\S*)?/i,
    };

    // Detect WhatsApp Group links
    if (antilinkSetting === '𝖜𝖍𝖆𝖙𝖘𝖆𝖕𝖕𝕲𝖗𝖔𝖚𝖕') {
        console.log('☀️ Protection des liens WhatsApp Group activée.');
        if (linkPatterns.whatsappGroup.test(userMessage)) {
            console.log('☀️ Lien WhatsApp Group détecté !');
            shouldDelete = true;
        }
    } else if (antilinkSetting === 'whatsappChannel' && linkPatterns.whatsappChannel.test(userMessage)) {
        shouldDelete = true;
    } else if (antilinkSetting === 'telegram' && linkPatterns.telegram.test(userMessage)) {
        shouldDelete = true;
    } else if (antilinkSetting === 'allLinks' && linkPatterns.allLinks.test(userMessage)) {
        shouldDelete = true;
    }

    if (shouldDelete) {
        const quotedMessageId = message.key.id; // Get the message ID to delete
        const quotedParticipant = message.key.participant || senderId; // Get the participant ID

        console.log(`☀️ Tentative de suppression du message ID: ${quotedMessageId} de: ${quotedParticipant}`);

        try {
            await sock.sendMessage(chatId, {
                delete: { remoteJid: chatId, fromMe: false, id: quotedMessageId, participant: quotedParticipant },
            });
            console.log(`☀️ Message ${quotedMessageId} supprimé.`);
        } catch (error) {
            console.error('☀️ Échec de la suppression:', error);
        }

        const mentionedJidList = [senderId];
        await sock.sendMessage(chatId, { text: `☀️ *ATTENTION !* @${senderId.split('@')[0]}, les liens sont interdits ici. Le Lion veille.`, mentions: mentionedJidList });
    } else {
        console.log('☀️ Aucun lien détecté ou protection non activée pour ce type.');
    }
}

module.exports = {
    handleAntilinkCommand,
    handleLinkDetection,
};