const fetch = require('node-fetch');

async function flirtCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/flirt?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const flirtMessage = json.result;

        // Send the flirt message
        await sock.sendMessage(chatId, { text: `☀️ *DRAGUE DU LION* ☀️\n\n${flirtMessage}` }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans la commande flirt:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA DRAGUE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.' }, { quoted: message });
    }
}

module.exports = { flirtCommand };