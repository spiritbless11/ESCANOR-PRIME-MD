const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const isOwnerOrSudo = require('../lib/isOwner');

async function setProfilePicture(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SEUL MON MAÎTRE PEUT CHANGER MA PHOTO.* ☀️' 
            });
            return;
        }

        const quotedMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quotedMessage) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *RÉPONDS À UNE IMAGE AVEC .setpp* ☀️' 
            });
            return;
        }

        const imageMessage = quotedMessage.imageMessage || quotedMessage.stickerMessage;
        if (!imageMessage) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *LE MESSAGE RÉPONDU DOIT CONTENIR UNE IMAGE.* ☀️' 
            });
            return;
        }

        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        const stream = await downloadContentFromMessage(imageMessage, 'image');
        let buffer = Buffer.from([]);
        
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        const imagePath = path.join(tmpDir, `profile_${Date.now()}.jpg`);
        
        fs.writeFileSync(imagePath, buffer);

        await sock.updateProfilePicture(sock.user.id, { url: imagePath });

        fs.unlinkSync(imagePath);

        await sock.sendMessage(chatId, { 
            text: '☀️ *PHOTO DE PROFIL MISE À JOUR.* ☀️\nLe Lion a une nouvelle image.' 
        });

    } catch (error) {
        console.error('☀️ Erreur dans setpp:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE LA MISE À JOUR.* ☀️' 
        });
    }
}

module.exports = setProfilePicture;