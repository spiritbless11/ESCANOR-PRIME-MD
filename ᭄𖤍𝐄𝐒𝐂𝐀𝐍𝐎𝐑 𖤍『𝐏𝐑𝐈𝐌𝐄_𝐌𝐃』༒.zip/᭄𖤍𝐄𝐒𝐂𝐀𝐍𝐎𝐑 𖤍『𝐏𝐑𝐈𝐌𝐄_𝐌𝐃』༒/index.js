/**
 * ╔═══════════════════════════════════════════════════════════════╗
 * ║  ༒ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒  WhatsApp Bot                 ║
 * ║  Le Lion de l'Orgueil – Celui qui se tient au-dessus de tout  ║
 * ║  Copyright (c) 2025 par ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒     ║
 * ║  Version PRIME – Puissance absolue                           ║
 * ╚═══════════════════════════════════════════════════════════════╝
 * 
 * Credits:
 * - Baileys Library by @adiwajshing
 * - Pair Code implementation inspiré par TechGod143 & DGXEON
 * - Adapté par BLESSDEV – L'orgueil est ma force, ma volonté est ma loi
 */
require('./settings')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const chalk = require('chalk')
const FileType = require('file-type')
const path = require('path')
const axios = require('axios')
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main');
const PhoneNumber = require('awesome-phonenumber')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, await, sleep, reSize } = require('./lib/myfunc')
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    jidDecode,
    proto,
    jidNormalizedUser,
    makeCacheableSignalKeyStore,
    delay
} = require("@whiskeysockets/baileys")
const NodeCache = require("node-cache")
const pino = require("pino")
const readline = require("readline")
const { parsePhoneNumber } = require("libphonenumber-js")
const { PHONENUMBER_MCC } = require('@whiskeysockets/baileys/lib/Utils/generics')
const { rmSync, existsSync } = require('fs')
const { join } = require('path')

const store = require('./lib/lightweight_store')

store.readFromFile()
const settings = require('./settings')
setInterval(() => store.writeToFile(), settings.storeWriteInterval || 10000)

setInterval(() => {
    if (global.gc) {
        global.gc()
        console.log('⚡ Puissance concentrée – Nettoyage des âmes faibles effectué.')
    }
}, 60_000)

setInterval(() => {
    const used = process.memoryUsage().rss / 1024 / 1024
    if (used > 400) {
        console.log('⚠️ La fièvre du Lion monte... Redémarrage pour libérer la puissance totale.')
        process.exit(1)
    }
}, 30_000)

let phoneNumber = "237681499373"
let owner = JSON.parse(fs.readFileSync('./data/owner.json'))

global.botname = "༒ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒"
global.themeemoji = "☀️"
const pairingCode = !!phoneNumber || process.argv.includes("--pairing-code")
const useMobile = process.argv.includes("--mobile")

const rl = process.stdin.isTTY ? readline.createInterface({ input: process.stdin, output: process.stdout }) : null
const question = (text) => {
    if (rl) {
        return new Promise((resolve) => rl.question(text, resolve))
    } else {
        return Promise.resolve(settings.ownerNumber || phoneNumber)
    }
}

async function startEscanorPrime() {
    try {
        let { version, isLatest } = await fetchLatestBaileysVersion()
        const { state, saveCreds } = await useMultiFileAuthState(`./session`)
        const msgRetryCounterCache = new NodeCache()

        const EscanorPrime = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: !pairingCode,
            browser: ["EscanorPrime", "Chrome", "120.0.0"],
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
            },
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            getMessage: async (key) => {
                let jid = jidNormalizedUser(key.remoteJid)
                let msg = await store.loadMessage(jid, key.id)
                return msg?.message || ""
            },
            msgRetryCounterCache,
            defaultQueryTimeoutMs: 60000,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 10000,
        })

        EscanorPrime.ev.on('creds.update', saveCreds)
        store.bind(EscanorPrime.ev)

        EscanorPrime.ev.on('messages.upsert', async chatUpdate => {
            try {
                const mek = chatUpdate.messages[0]
                if (!mek.message) return
                mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
                if (mek.key && mek.key.remoteJid === 'status@broadcast') {
                    await handleStatus(EscanorPrime, chatUpdate);
                    return;
                }
                if (!EscanorPrime.public && !mek.key.fromMe && chatUpdate.type === 'notify') {
                    const isGroup = mek.key?.remoteJid?.endsWith('@g.us')
                    if (!isGroup) return
                }
                if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return

                if (EscanorPrime?.msgRetryCounterCache) {
                    EscanorPrime.msgRetryCounterCache.clear()
                }

                try {
                    await handleMessages(EscanorPrime, chatUpdate, true)
                } catch (err) {
                    console.error("Erreur dans le traitement des messages:", err)
                    if (mek.key && mek.key.remoteJid) {
                        await EscanorPrime.sendMessage(mek.key.remoteJid, {
                            text: '🔥 *Tu as osé me défier ?* Une erreur s\'est produite, mais le Lion ne tombe jamais. Réessaie, mortel.',
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: '120363419277738229@newsletter',
                                    newsletterName: '༒ ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒',
                                    serverMessageId: -1
                                }
                            }
                        }).catch(console.error);
                    }
                }
            } catch (err) {
                console.error("Erreur dans messages.upsert:", err)
            }
        })

        EscanorPrime.decodeJid = (jid) => {
            if (!jid) return jid
            if (/:\d+@/gi.test(jid)) {
                let decode = jidDecode(jid) || {}
                return decode.user && decode.server && decode.user + '@' + decode.server || jid
            } else return jid
        }

        EscanorPrime.ev.on('contacts.update', update => {
            for (let contact of update) {
                let id = EscanorPrime.decodeJid(contact.id)
                if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
            }
        })

        EscanorPrime.getName = (jid, withoutContact = false) => {
            id = EscanorPrime.decodeJid(jid)
            withoutContact = EscanorPrime.withoutContact || withoutContact
            let v
            if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
                v = store.contacts[id] || {}
                if (!(v.name || v.subject)) v = EscanorPrime.groupMetadata(id) || {}
                resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
            })
            else v = id === '0@s.whatsapp.net' ? {
                id,
                name: 'WhatsApp'
            } : id === EscanorPrime.decodeJid(EscanorPrime.user.id) ?
                EscanorPrime.user :
                (store.contacts[id] || {})
            return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
        }

        EscanorPrime.public = true
        EscanorPrime.serializeM = (m) => smsg(EscanorPrime, m, store)

        if (pairingCode && !EscanorPrime.authState.creds.registered) {
            if (useMobile) throw new Error('Mode mobile non supporté pour le code de couple')

            let phoneNumber
            if (!!global.phoneNumber) {
                phoneNumber = global.phoneNumber
            } else {
                phoneNumber = await question(chalk.bgBlack(chalk.brightRed(`☀️ *PRIDE OF LIONS* ☀️\nEntre ton numéro WhatsApp, mortel.\nFormat: 237681499373 (sans + ni espaces) : `)))
            }

            phoneNumber = phoneNumber.replace(/[^0-9]/g, '')

            const pn = require('awesome-phonenumber');
            if (!pn('+' + phoneNumber).isValid()) {
                console.log(chalk.red('❌ Numéro invalide. Même le soleil se couche sur les imbéciles. Réessaie.'));
                process.exit(1);
            }

            setTimeout(async () => {
                try {
                    let code = await EscanorPrime.requestPairingCode(phoneNumber)
                    code = code?.match(/.{1,4}/g)?.join("-") || code
                    console.log(chalk.black(chalk.bgBrightRed(`☀️ CODE DE FIERTÉ : `)), chalk.black(chalk.white(code)))
                    console.log(chalk.yellow(`\n🔥 *Écoute, vermisseau.* Entre ce code dans WhatsApp:\n1. Ouvre WhatsApp\n2. Paramètres → Appareils liés\n3. Tape "Lier un appareil"\n4. Entre ce code. Ne me fais pas attendre.`))
                } catch (error) {
                    console.error('Erreur lors de la demande du code:', error)
                    console.log(chalk.red('❌ Le code n\'a pas pu être généré. Le Lion rugit de frustration. Vérifie ton numéro.'))
                }
            }, 3000)
        }

        EscanorPrime.ev.on('connection.update', async (s) => {
            const { connection, lastDisconnect, qr } = s
            
            if (qr) {
                console.log(chalk.yellow('☀️ QR Code généré. Scanne-le, si tu oses.'))
            }
            
            if (connection === 'connecting') {
                console.log(chalk.yellow('🔥 Le soleil se lève... Connexion en cours.'))
            }
            
            if (connection == "open") {
                console.log(chalk.magenta(` `))
                console.log(chalk.yellow(`☀️ *LE LION EST RÉVEILLÉ* ☀️\nConnecté en tant que : ` + JSON.stringify(EscanorPrime.user, null, 2)))

                try {
                    const botNumber = EscanorPrime.user.id.split(':')[0] + '@s.whatsapp.net';
                    await EscanorPrime.sendMessage(botNumber, {
                        text: `☀️ *PRIDE OF LIONS – ESCANOR PRIME* ☀️\n\n🔥 *Je suis Escanor, le Lion de l'Orgueil.* Celui qui se tient au-dessus de tout. Mon bot est désormais éveillé, et avec lui, c'est la puissance absolue qui entre en jeu.\n\n⚡ *Statut :* PRIME – Puissance maximale atteinte\n⏰ *Heure du lever :* ${new Date().toLocaleString()}\n\n💬 *Rappelle-toi, mortel :* Derrière ce bot se tient mon maître, le seul que je daigne reconnaître.\n📢 Rejoins ma chaîne, si ton cœur est assez vaillant.\n\n*Prie pour ne pas croiser ma route.* ☀️`,
                        contextInfo: {
                            forwardingScore: 1,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363419277738229@newsletter',
                                newsletterName: '༒ ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒',
                                serverMessageId: -1
                            }
                        }
                    });
                } catch (error) {
                    console.error('Erreur lors de l\'envoi du message de connexion:', error.message)
                }

                await delay(1999)
                console.log(chalk.yellow(`\n\n                  ${chalk.bold.red(`[ ${global.botname || '༒ ESCANOR PRIME ༒'} ]`)}\n\n`))
                console.log(chalk.cyan(`< ================================================== >`))
                console.log(chalk.magenta(`\n${global.themeemoji || '☀️'} *MAÎTRE SUPRÊME :* ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒`))
                console.log(chalk.magenta(`${global.themeemoji || '☀️'} *CANAL OFFICIEL :* https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K`))
                console.log(chalk.magenta(`${global.themeemoji || '☀️'} *GITHUB :* BLESSDEV/SYS_HACKED`))
                console.log(chalk.magenta(`${global.themeemoji || '☀️'} *NUMÉRO OWNER :* ${owner}`))
                console.log(chalk.green(`${global.themeemoji || '☀️'} ✅ *EScanor PRIME est opérationnel. La puissance absolue est à portée de main.*`))
                console.log(chalk.blue(`📌 *Version du Bot :* ${settings.version} – The One Ultimate`))
            }
            
            if (connection === 'close') {
                const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut
                const statusCode = lastDisconnect?.error?.output?.statusCode
                
                console.log(chalk.red(`Connexion fermée. Raison : ${lastDisconnect?.error}. Reconnexion : ${shouldReconnect}`))
                
                if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
                    try {
                        rmSync('./session', { recursive: true, force: true })
                        console.log(chalk.yellow('Session expirée. Le Lion se retire pour renaître.'))
                    } catch (error) {
                        console.error('Erreur lors de la suppression de session:', error)
                    }
                    console.log(chalk.red('Déconnecté. Authentification requise.'))
                }
                
                if (shouldReconnect) {
                    console.log(chalk.yellow('🔥 Le soleil se lève à nouveau. Reconnexion...'))
                    await delay(5000)
                    startEscanorPrime()
                }
            }
        })

        const antiCallNotified = new Set();

        EscanorPrime.ev.on('call', async (calls) => {
            try {
                const { readState: readAnticallState } = require('./commands/anticall');
                const state = readAnticallState();
                if (!state.enabled) return;
                for (const call of calls) {
                    const callerJid = call.from || call.peerJid || call.chatId;
                    if (!callerJid) continue;
                    try {
                        try {
                            if (typeof EscanorPrime.rejectCall === 'function' && call.id) {
                                await EscanorPrime.rejectCall(call.id, callerJid);
                            } else if (typeof EscanorPrime.sendCallOfferAck === 'function' && call.id) {
                                await EscanorPrime.sendCallOfferAck(call.id, callerJid, 'reject');
                            }
                        } catch {}

                        if (!antiCallNotified.has(callerJid)) {
                            antiCallNotified.add(callerJid);
                            setTimeout(() => antiCallNotified.delete(callerJid), 60000);
                            await EscanorPrime.sendMessage(callerJid, { text: '☀️ *OSES-TU DÉRANGER LE LION ?* ☀️\nAppel rejeté. Tu vas être bloqué. La prochaine fois, réfléchis à deux fois avant de défier la fierté absolue.' });
                        }
                    } catch {}
                    setTimeout(async () => {
                        try { await EscanorPrime.updateBlockStatus(callerJid, 'block'); } catch {}
                    }, 800);
                }
            } catch (e) {}
        });

        EscanorPrime.ev.on('group-participants.update', async (update) => {
            await handleGroupParticipantUpdate(EscanorPrime, update);
        });

        EscanorPrime.ev.on('messages.upsert', async (m) => {
            if (m.messages[0].key && m.messages[0].key.remoteJid === 'status@broadcast') {
                await handleStatus(EscanorPrime, m);
            }
        });

        EscanorPrime.ev.on('status.update', async (status) => {
            await handleStatus(EscanorPrime, status);
        });

        EscanorPrime.ev.on('messages.reaction', async (status) => {
            await handleStatus(EscanorPrime, status);
        });

        return EscanorPrime
    } catch (error) {
        console.error('Erreur dans startEscanorPrime:', error)
        await delay(5000)
        startEscanorPrime()
    }
}

startEscanorPrime().catch(error => {
    console.error('Erreur fatale:', error)
    process.exit(1)
})

process.on('uncaughtException', (err) => {
    console.error('Exception non capturée:', err)
})

process.on('unhandledRejection', (err) {
    console.error('Promesse rejetée non gérée:', err)
})

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`☀️ Mise à jour du fichier ${__filename} – Le Lion s'adapte.`))
    delete require.cache[file]
    require(file)
})