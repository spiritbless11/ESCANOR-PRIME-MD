// ================================
// PRIDE OF LIONS MENU SYSTEM - ESCANOR PRIME
// Help menu principal & .devinfo
// ================================

const { channelInfo } = require('../lib/messageConfig');

/* Channel official link - La fierté du Lion */
const channelLink = "https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K";

/* ☀️ Random videos for menus - La puissance du soleil */
const mainVideos = [
    "https://image2url.com/r2/default/videos/1769779207593-673c49d9-dc92-40f6-9a97-69bbbbd850b0.mp4",
    "https://image2url.com/r2/default/videos/1769865468877-c39e06b5-1a4a-4dea-ab19-e3b37d13f847.mp4",
    "https://image2url.com/r2/default/videos/1769865533089-a17a2866-7859-4e5e-83b8-156c84898ba0.mp4"
];
const devVideos = [
    "https://image2url.com/r2/default/videos/1769865636958-ed88f56a-69af-48cb-afed-10b1fc2f29db.mp4",
    "https://image2url.com/r2/default/videos/1769865828614-23e460cb-7c7c-474d-9616-1a1e08f799e3.mp4",
    "https://image2url.com/r2/default/videos/1769866189639-79ab6159-cc37-402c-a3d4-6d8c747ca9a8.mp4"
];

const randomVideo = (videos) => videos[Math.floor(Math.random() * videos.length)];

/* ☀️ Random images for newsletter - La gloire du Lion */
const mainImages = [
    "https://images.iimg.live/images/excellent-collection-4057.webp",
    "https://images.iimg.live/images/wonderful-photo-8175.webp",
    "https://images.iimg.live/images/dynamic-masterpiece-7165.webp"
];
const randomMainImage = () => mainImages[Math.floor(Math.random() * mainImages.length)];

/* 📰 Newsletter context - La voix du maître */
const newsletterContext = (imageUrl) => ({
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363419277738229@newsletter',
        newsletterName: '༒ ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒',
        serverMessageId: Math.floor(Math.random() * 1000)
    },
    externalAdReply: {
        title: "☀️ 𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𝐏𝐑𝐈𝐌𝐄 ☀️",
        body: "Celui qui se tient au-dessus de tout",
        thumbnailUrl: imageUrl,
        mediaType: 1,
        renderLargerThumbnail: true,
        sourceUrl: channelLink
    }
});

/* ☀️ Send Main Menu - Le rugissement du Lion */
const sendMainMenu = async (sock, chatId, message, text) => {
    const videoUrl = randomVideo(mainVideos);
    const imageUrl = randomMainImage();

    return sock.sendMessage(chatId, {
        video: { url: videoUrl },
        caption: `${text} *༒ ESCANOR PRIME ༒*`,
        mimetype: "video/mp4",
        contextInfo: newsletterContext(imageUrl)
    }, { quoted: message });
};

/* ☀️ Send Section Menu - La puissance déployée */
const sendSectionMenu = async (sock, chatId, message, text, profilePicUrl) => {
    return sock.sendMessage(chatId, {
        image: { url: profilePicUrl },
        caption: `${text}\n
╭━━━〔 ☀️ ᴘʀɪᴅᴇ ᴏꜰ ʟɪᴏɴꜱ ☀️ 〕━━━╮
┃  ☀️ ʙᴏᴛ : ༒ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
        contextInfo: newsletterContext(profilePicUrl)
    }, { quoted: message });
};

/* ☀️ Main Help Menu - La fierté absolue */
const helpCommand = async (sock, chatId, message) => {
    const text = `
╭━━━〔 ☀️ 𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𝐏𝐑𝐈𝐌𝐄 – 𝐋𝐄 𝐋𝐈𝐎𝐍 𝐃𝐄 𝐋'𝐎𝐑𝐆𝐔𝐄𝐈𝐋 ☀️ 〕━━━
┃
┃ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ │〔 🔥 𝐏𝐔𝐈𝐒𝐒𝐀𝐍𝐂𝐄 𝐀𝐁𝐒𝐎𝐋𝐔𝐄 🔥 〕│
┃ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
┃
┃ 🧠  .general - 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 𝐆𝐄́𝐍𝐄́𝐑𝐀𝐋𝐄𝐒
┃ 👥  .group - 𝐆𝐄𝐒𝐓𝐈𝐎𝐍 𝐃𝐄𝐒 𝐆𝐑𝐎𝐔𝐏𝐄𝐒
┃ 👑  .owner - 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 𝐃𝐔 𝐌𝐀𝐈̂𝐓𝐑𝐄
┃ 🤖  .ai - 𝐈𝐍𝐓𝐄𝐋𝐋𝐈𝐆𝐄𝐍𝐂𝐄 𝐀𝐑𝐓𝐈𝐅𝐈𝐂𝐈𝐄𝐋𝐋𝐄
┃ 🎨  .stickmenu - 𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒 & 𝐄𝐌𝐎𝐉𝐈𝐒
┃ 🌐  .social - 𝐑𝐄́𝐒𝐄𝐀𝐔𝐗 & 𝐌𝐄́𝐃𝐈𝐀𝐒
┃ 🛠  .tools - 𝐎𝐔𝐓𝐈𝐋𝐒 𝐃𝐈𝐕𝐄𝐑𝐒
┃ 🎮  .games - 𝐉𝐄𝐔𝐗 𝐈𝐍𝐓𝐄𝐑𝐀𝐂𝐓𝐈𝐅𝐒
┃ 📦  .misc - 𝐔𝐓𝐈𝐋𝐈𝐓𝐀𝐈𝐑𝐄𝐒
┃ 🖥  .devinfo - 𝐋𝐄 𝐌𝐀𝐈̂𝐓𝐑𝐄 𝐃𝐄𝐑𝐑𝐈𝐄̀𝐑𝐄 𝐋𝐄 𝐋𝐈𝐎𝐍
╰─────────────────────────────────────

╭── 「 ☀️ 𝐋𝐄 𝐌𝐀𝐈̂𝐓𝐑𝐄 𝐐𝐔𝐈 𝐌'𝐀 𝐅𝐀𝐂̧𝐎𝐍𝐍𝐄́ ☀️ 」
┃ 👑 𝐌𝐀𝐈̂𝐓𝐑𝐄 𝐒𝐔𝐏𝐑𝐄̂𝐌𝐄 : ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒
┃ 📢 𝐂𝐇𝐀𝐈̂𝐍𝐄 𝐎𝐅𝐅𝐈𝐂𝐈𝐄𝐋𝐋𝐄 : ${channelLink}
┃ 🔗 𝐆𝐑𝐎𝐔𝐏𝐄 : https://chat.whatsapp.com/B5PZoLePELTLXzDkTboMno
╰─────────────────────────────────────

☀️ *"Je suis celui qui se tient au-dessus de tout. Qui ose me défier ?"* ☀️

© ༒ ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒`;

    await sendMainMenu(sock, chatId, message, text);
};

/* 📂 Section Menus - Les commandes du Lion */
const menuSystem = async (sock, chatId, message, section) => {
    try {
        const botJid = sock.user.id;
        let profilePicUrl;
        try {
            profilePicUrl = await sock.profilePictureUrl(botJid, 'image');
        } catch {
            profilePicUrl = 'https://files.catbox.moe/1fkaha.jpg';
        }

        const sectionsText = {
    general: `
╭━━━〔 ☀️ 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 𝐆𝐄́𝐍𝐄́𝐑𝐀𝐋𝐄𝐒 ☀️ 〕━━━╮
┃ 🔥 La puissance de base du Lion
┃
┃ ✦ .ping - Tester la réactivité du bot
┃ ✦ .tts <texte> - Synthèse vocale
┃ ✦ .weather <ville> - Météo actuelle
┃ ✦ .alive - Vérifier si je suis là, mortel
┃ ✦ .news - Dernières actualités
┃ ✦ .lyrics <chanson> - Paroles de musique
┃ ✦ .8ball <question> - Réponse du destin
┃ ✦ .translate <texte> - Traduction instantanée
┃ ✦ .autostatus - Auto vue des statuts
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    group: `
╭━━━〔 ☀️ 𝐆𝐄𝐒𝐓𝐈𝐎𝐍 𝐃𝐄𝐒 𝐆𝐑𝐎𝐔𝐏𝐄𝐒 ☀️ 〕━━━╮
┃ 👑 Je fais régner l'ordre dans tes groupes
┃
┃ ✦ .ban - Bannir un insolent
┃ ✦ .unban - Pardonner (rare)
┃ ✦ .promote - Élever un mortel
┃ ✦ .demote - Le faire redescendre
┃ ✦ .mute - Faire taire le groupe
┃ ✦ .unmute - Redonner la parole
┃ ✦ .kick - Expulser un indésirable
┃ ✦ .delete - Supprimer un message
┃ ✦ .clear - Nettoyer le chat
┃ ✦ .welcome <on/off> - Activer l'accueil
┃ ✦ .antilink - Bloquer les liens
┃ ✦ .antibadword - Propreté du groupe
┃ ✦ .tagall - Mentionner tout le monde
┃ ✦ .hidetag - Mention cachée
┃ ✦ .purge - Nettoyage en profondeur
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    owner: `
╭━━━〔 ☀️ 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒 𝐃𝐔 𝐌𝐀𝐈̂𝐓𝐑𝐄 ☀️ 〕━━━╮
┃ 👑 Mon maître est le seul que je respecte
┃
┃ ✦ .mode <public/private> - Changer le mode
┃ ✦ .update - Mettre à jour le Lion
┃ ✦ .settings - Voir la configuration
┃ ✦ .autotyping - Simulation de frappe
┃ ✦ .autoread - Lecture auto des messages
┃ ✦ .anticall - Bloquer les appels
┃ ✦ .pmblocker - Bloquer les MPs
┃ ✦ .cleartmp - Nettoyer les fichiers
┃ ✦ .clearsession - Réinitialiser la session
┃ ✦ .setpp - Changer ma photo de profil
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    ai: `
╭━━━〔 ☀️ 𝐈𝐍𝐓𝐄𝐋𝐋𝐈𝐆𝐄𝐍𝐂𝐄 𝐀𝐑𝐓𝐈𝐅𝐈𝐂𝐈𝐄𝐋𝐋𝐄 ☀️ 〕━━━╮
┃ 🤖 Même les IA s'inclinent devant moi
┃
┃ ✦ .gpt - GPT-4, la puissance cognitive
┃ ✦ .gemini - L'IA de Google
┃ ✦ .imagine - Générer une image
┃ ✦ .flux - Génération avancée
┃ ✦ .sora - Vidéo par IA
┃ ✦ .compliment - Un compliment du Lion
┃ ✦ .flirt - Tenter de me charmer ?
┃ ✦ .insult - Une insulte cinglante
┃ ✦ .stupid - Pour les imbéciles
┃ ✦ .truth - Vérité ou défi
┃ ✦ .dare - Osez, si vous le pouvez
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    stickmenu: `
╭━━━〔 ☀️ 𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒 & 𝐄𝐌𝐎𝐉𝐈𝐒 ☀️ 〕━━━╮
┃ 🎨 Créez des stickers dignes du Lion
┃
┃ ✦ .sticker - Convertir image en sticker
┃ ✦ .take - Voler un sticker
┃ ✦ .tg - Sticker animé
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    social: `
╭━━━〔 ☀️ 𝐑𝐄́𝐒𝐄𝐀𝐔𝐗 & 𝐌𝐄́𝐃𝐈𝐀𝐒 ☀️ 〕━━━╮
┃ 🌐 Le monde s'offre à toi
┃
┃ ✦ .tiktok <lien> - Télécharger TikTok
┃ ✦ .facebook <lien> - Vidéo Facebook
┃ ✦ .instagram <lien> - Reel Instagram
┃ ✦ .spotify - Musique Spotify
┃ ✦ .play - Jouer une musique
┃ ✦ .song - Trouver une chanson
┃ ✦ .video - Télécharger une vidéo
┃ ✦ .music - Musique en ligne
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    tools: `
╭━━━〔 ☀️ 𝐎𝐔𝐓𝐈𝐋𝐒 𝐃𝐈𝐕𝐄𝐑𝐒 ☀️ 〕━━━╮
┃ 🛠 Des outils pour les mortels
┃
┃ ✦ .shorturl <lien> - Raccourcir un lien
┃ ✦ .qrcode <texte> - Générer un QR code
┃ ✦ .ss <url> - Capture d'écran
┃ ✦ .url <lien> - Analyser un lien
┃ ✦ .ai <question> - Question à l'IA
┃ ✦ .setpp - Changer ma photo
┃ ✦ .repo - Lien du dépôt
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    games: `
╭━━━〔 ☀️ 𝐉𝐄𝐔𝐗 𝐈𝐍𝐓𝐄𝐑𝐀𝐂𝐓𝐈𝐅𝐒 ☀️ 〕━━━╮
┃ 🎮 Amuse-toi, si tu en es capable
┃
┃ ✦ .tictactoe - Morpion
┃ ✦ .hangman - Pendu
┃ ✦ .trivia - Quiz
┃ ✦ .dice - Lancer de dé
┃ ✦ .rps <rock/paper/scissors> - Pierre feuille ciseaux
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    misc: `
╭━━━〔 ☀️ 𝐔𝐓𝐈𝐋𝐈𝐓𝐀𝐈𝐑𝐄𝐒 ☀️ 〕━━━╮
┃ 📦 Divers, pour te distraire
┃
┃ ✦ .quote - Citation aléatoire
┃ ✦ .fact - Fait insolite
┃ ✦ .joke - Une blague (tente de me faire rire)
┃ ✦ .compliment - Un compliment
┃ ✦ .insult - Une insulte
┃ ✦ .roseday - Message pour la Saint-Valentin
┃ ✦ .shayari - Poésie
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`,
    devinfo: `
╭━━━〔 ☀️ 𝐋𝐄 𝐌𝐀𝐈̂𝐓𝐑𝐄 𝐃𝐄𝐑𝐑𝐈𝐄̀𝐑𝐄 𝐋𝐄 𝐋𝐈𝐎𝐍 ☀️ 〕━━━╮
┃ 👑 *MAÎTRE SUPRÊME :* ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒
┃
┃ 🔥 *Lien de la chaîne :* ${channelLink}
┃ 🔥 *Lien du groupe :* https://chat.whatsapp.com/B5PZoLePELTLXzDkTboMno
┃
┃ ☀️ *"Sans lui, je ne serais que poussière. Lui seul a dompté ma fierté."*
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`
        };

        if (!sectionsText[section]) return sock.sendMessage(chatId, { text: '❌ Section inconnue, mortel. Essaie .menu pour voir ce que je te propose.' });

        // For .devinfo use random video with pride
        if (section === 'devinfo') {
            const videoUrl = randomVideo(devVideos);
            return sock.sendMessage(chatId, {
                video: { url: videoUrl },
                caption: sectionsText.devinfo + `\n☀️ © ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒`,
                mimetype: "video/mp4",
                contextInfo: newsletterContext(profilePicUrl)
            }, { quoted: message });
        }

        await sendSectionMenu(sock, chatId, message, sectionsText[section], profilePicUrl);

    } catch (error) {
        console.error('Erreur dans menuSystem:', error);
        await sock.sendMessage(chatId, { text: '☀️ Une erreur s\'est produite. Même le Lion peut avoir un hoquet. Réessaie plus tard, mortel.' });
    }
};

module.exports = { helpCommand, menuSystem };